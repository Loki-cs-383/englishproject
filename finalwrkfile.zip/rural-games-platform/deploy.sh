#!/bin/bash

# Rural Games Platform Deployment Script

echo "🚀 Starting Rural Games Platform Deployment..."

# Check if Heroku CLI is installed
if ! command -v heroku &> /dev/null; then
    echo "❌ Heroku CLI is not installed. Please install it first."
    echo "   Visit: https://devcenter.heroku.com/articles/heroku-cli"
    exit 1
fi

# Check if logged in to Heroku
heroku whoami &> /dev/null
if [ $? -ne 0 ]; then
    echo "❌ Not logged in to Heroku. Please login first."
    heroku login
fi

# Deploy Backend
echo "🔄 Deploying Backend to Heroku..."

cd backend

# Create Heroku app for backend if it doesn't exist
heroku apps:info rural-games-api &> /dev/null
if [ $? -ne 0 ]; then
    echo "📦 Creating new Heroku app for backend..."
    heroku create rural-games-api
else
    echo "✅ Using existing Heroku app for backend: rural-games-api"
fi

# Set environment variables
echo "⚙️ Setting environment variables..."
heroku config:set NODE_ENV=production --app rural-games-api
heroku config:set JWT_SECRET=your-super-secure-jwt-secret-key-change-this-in-production --app rural-games-api
heroku config:set FRONTEND_URL=https://rural-games-platform.netlify.app --app rural-games-api

# Add MongoDB Atlas
echo "🗄️ Setting up MongoDB Atlas connection..."
echo "❓ Please enter your MongoDB Atlas connection string:"
read -s MONGODB_URI
heroku config:set MONGODB_URI=$MONGODB_URI --app rural-games-api

# Deploy to Heroku
echo "🚀 Deploying backend code..."
git init
git add .
git commit -m "Deploy backend to Heroku"
git push heroku master --force

# Deploy Frontend
echo "🔄 Deploying Frontend to Netlify..."
cd ../frontend

# Build frontend
echo "🔨 Building frontend..."
./build.sh

# Check if Netlify CLI is installed
if ! command -v netlify &> /dev/null; then
    echo "❌ Netlify CLI is not installed. Please install it first."
    echo "   Run: npm install -g netlify-cli"
    exit 1
fi

# Deploy to Netlify
echo "🚀 Deploying frontend code..."
cd build
netlify deploy --prod

echo "✅ Deployment completed!"
echo ""
echo "📍 Access Points:"
echo "   Backend API: https://rural-games-api.herokuapp.com"
echo "   Frontend: Check the Netlify URL provided above"
echo ""
echo "🎮 Enjoy your Rural Games Platform!"