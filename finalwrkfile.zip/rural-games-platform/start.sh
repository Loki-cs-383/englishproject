#!/bin/bash

# Rural Games Platform Startup Script
# This script starts both backend and frontend servers

echo "🎮 Starting Rural Games Platform..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    exit 1
fi

# Check if MongoDB is running
if ! command -v mongod &> /dev/null; then
    echo "⚠️  MongoDB is not installed. Please install MongoDB first."
    echo "   You can also use MongoDB Atlas for cloud database."
fi

# Function to check if port is in use
check_port() {
    local port=$1
    if lsof -Pi :$port -sTCP:LISTEN -t >/dev/null ; then
        echo "Port $port is already in use."
        return 1
    fi
    return 0
}

# Start Backend
echo "📡 Starting Backend Server..."
cd backend

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo "📦 Installing backend dependencies..."
    npm install
fi

# Check if port 5000 is available
if ! check_port 5000; then
    echo "⚠️  Backend port 5000 is in use. Please stop the other process or change the port."
fi

# Initialize database if needed
echo "🗄️  Initializing database..."
node ../database/init.js

# Start backend server
echo "🚀 Starting backend server on port 5000..."
npm run dev &
BACKEND_PID=$!

cd ..

# Wait a moment for backend to start
sleep 3

# Start Frontend
echo "🌐 Starting Frontend Server..."
cd frontend

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo "📦 Installing frontend dependencies..."
    npm install
fi

# Check if port 3000 is available
if ! check_port 3000; then
    echo "⚠️  Frontend port 3000 is in use. Please stop the other process or change the port."
fi

# Start frontend server
echo "🚀 Starting frontend server on port 3000..."
npm start &
FRONTEND_PID=$!

cd ..

echo ""
echo "✅ Rural Games Platform is starting up..."
echo ""
echo "📍 Access Points:"
echo "   Frontend: http://localhost:3000"
echo "   Backend API: http://localhost:5000"
echo "   API Health: http://localhost:5000/health"
echo ""
echo "📝 Logs:"
echo "   Backend logs are displayed above"
echo "   Frontend will open in your default browser"
echo ""
echo "🛑 To stop the servers:"
echo "   Press Ctrl+C or run: ./stop.sh"
echo ""

# Function to cleanup on exit
cleanup() {
    echo ""
    echo "🛑 Stopping servers..."
    
    if [ ! -z "$BACKEND_PID" ]; then
        kill $BACKEND_PID 2>/dev/null
        echo "✅ Backend server stopped"
    fi
    
    if [ ! -z "$FRONTEND_PID" ]; then
        kill $FRONTEND_PID 2>/dev/null
        echo "✅ Frontend server stopped"
    fi
    
    echo "👋 Rural Games Platform stopped. Goodbye!"
    exit 0
}

# Set up signal handlers
trap cleanup SIGINT SIGTERM

# Wait for processes
wait