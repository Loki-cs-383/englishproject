# Production Environment Configuration Guide

This guide explains how to configure environment variables for deploying the Rural Games Platform to production.

## Backend Environment Variables

When deploying to production, you need to set the following environment variables:

### Core Configuration
```
NODE_ENV=production
PORT=5000 (or the port provided by your hosting platform)
```

### Database Configuration
```
MONGODB_URI=mongodb+srv://username:password@cluster0.mongodb.net/rural-games-platform?retryWrites=true&w=majority
```
Replace with your actual MongoDB Atlas connection string.

### Security Configuration
```
JWT_SECRET=your-very-secure-jwt-secret-key-here
JWT_EXPIRE=7d
```
Generate a strong random string for JWT_SECRET. Never use the default value in production.

### CORS Configuration
```
FRONTEND_URL=https://your-frontend-domain.com
```
Set this to the URL where your frontend is hosted.

### Rate Limiting
```
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```
Adjust these values based on your expected traffic.

## Setting Environment Variables on Different Platforms

### Heroku
```bash
heroku config:set NODE_ENV=production --app your-app-name
heroku config:set MONGODB_URI=your-mongodb-uri --app your-app-name
heroku config:set JWT_SECRET=your-jwt-secret --app your-app-name
heroku config:set FRONTEND_URL=https://your-frontend-domain.com --app your-app-name
```

### Netlify (Frontend)
In the Netlify dashboard:
1. Go to Site settings > Build & deploy > Environment
2. Add environment variables:
```
API_URL=https://your-backend-api.com/api
```

### AWS Elastic Beanstalk
```bash
eb setenv NODE_ENV=production
eb setenv MONGODB_URI=your-mongodb-uri
eb setenv JWT_SECRET=your-jwt-secret
eb setenv FRONTEND_URL=https://your-frontend-domain.com
```

### Docker
In your docker-compose.yml file:
```yaml
services:
  backend:
    environment:
      - NODE_ENV=production
      - MONGODB_URI=your-mongodb-uri
      - JWT_SECRET=your-jwt-secret
      - FRONTEND_URL=https://your-frontend-domain.com
```

## Generating a Secure JWT Secret

Use this command to generate a secure random string for your JWT_SECRET:

```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

## Environment Variables Security Best Practices

1. **Never commit environment variables to your repository**
2. Use a `.env.example` file to document required variables without values
3. Use a secure password manager to store sensitive values
4. Rotate secrets regularly, especially JWT_SECRET
5. Use different secrets for development, staging, and production
6. Limit access to production environment variables to essential team members
7. Use environment variable encryption when available on your platform
8. Audit environment variable access and changes

## Checking Environment Configuration

To verify your environment configuration is correct, you can add this code to your server.js file:

```javascript
// Log environment configuration (remove in production)
if (process.env.NODE_ENV === 'development') {
  console.log('Environment Configuration:');
  console.log(`- NODE_ENV: ${process.env.NODE_ENV}`);
  console.log(`- PORT: ${process.env.PORT}`);
  console.log(`- MONGODB_URI: ${process.env.MONGODB_URI ? '[CONFIGURED]' : '[MISSING]'}`);
  console.log(`- JWT_SECRET: ${process.env.JWT_SECRET ? '[CONFIGURED]' : '[MISSING]'}`);
  console.log(`- FRONTEND_URL: ${process.env.FRONTEND_URL}`);
}
```

This will help you confirm that all required variables are properly set.