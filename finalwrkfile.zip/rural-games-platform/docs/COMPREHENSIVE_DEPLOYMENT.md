# Comprehensive Deployment Guide for Rural Games Platform

This guide provides detailed instructions for deploying the Rural Games Platform to production environments.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Database Setup](#database-setup)
3. [Backend Deployment](#backend-deployment)
4. [Frontend Deployment](#frontend-deployment)
5. [Environment Configuration](#environment-configuration)
6. [Continuous Integration/Deployment](#continuous-integrationdeployment)
7. [Post-Deployment Verification](#post-deployment-verification)
8. [Troubleshooting](#troubleshooting)

## Prerequisites

Before deploying, ensure you have:

- Git installed
- Node.js (v18.x recommended) installed
- MongoDB Atlas account (for database)
- Heroku account and Heroku CLI installed (for backend)
- Netlify account and Netlify CLI installed (for frontend)
- GitHub account (for CI/CD)

## Database Setup

Follow these steps to set up your MongoDB Atlas database:

1. **Create MongoDB Atlas Account**
   - Sign up at [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)

2. **Create a Cluster**
   - Choose the FREE tier
   - Select your preferred cloud provider and region

3. **Configure Database Access**
   - Create a database user with a strong password
   - Grant appropriate permissions (Atlas admin for simplicity)

4. **Configure Network Access**
   - Allow access from your deployment servers
   - For development, you can allow access from anywhere

5. **Get Connection String**
   - Format: `mongodb+srv://username:password@cluster0.mongodb.net/rural-games-platform?retryWrites=true&w=majority`
   - Replace username, password, and database name

For detailed instructions, see [MONGODB_ATLAS_SETUP.md](./MONGODB_ATLAS_SETUP.md)

## Backend Deployment

### Option 1: Heroku Deployment (Recommended)

1. **Login to Heroku**
   ```bash
   heroku login
   ```

2. **Create a Heroku App**
   ```bash
   cd backend
   heroku create rural-games-api
   ```

3. **Set Environment Variables**
   ```bash
   heroku config:set NODE_ENV=production
   heroku config:set MONGODB_URI=your-mongodb-atlas-connection-string
   heroku config:set JWT_SECRET=your-secure-jwt-secret
   heroku config:set FRONTEND_URL=https://your-frontend-url.netlify.app
   ```

4. **Deploy to Heroku**
   ```bash
   git add .
   git commit -m "Deploy to Heroku"
   git push heroku master
   ```

5. **Verify Deployment**
   ```bash
   heroku open
   ```

### Option 2: AWS Elastic Beanstalk

1. **Install EB CLI**
   ```bash
   pip install awsebcli
   ```

2. **Initialize EB Application**
   ```bash
   cd backend
   eb init rural-games-api
   ```

3. **Create Environment**
   ```bash
   eb create production
   ```

4. **Set Environment Variables**
   ```bash
   eb setenv NODE_ENV=production MONGODB_URI=your-mongodb-uri JWT_SECRET=your-jwt-secret FRONTEND_URL=https://your-frontend-url.netlify.app
   ```

5. **Deploy**
   ```bash
   eb deploy
   ```

### Option 3: Docker Deployment

1. **Create Dockerfile in backend directory**
   ```dockerfile
   FROM node:18-alpine
   WORKDIR /app
   COPY package*.json ./
   RUN npm ci --only=production
   COPY . .
   EXPOSE 5000
   CMD ["node", "server.js"]
   ```

2. **Build and Run Docker Image**
   ```bash
   docker build -t rural-games-api .
   docker run -p 5000:5000 --env-file .env rural-games-api
   ```

## Frontend Deployment

### Option 1: Netlify Deployment (Recommended)

1. **Build Frontend**
   ```bash
   cd frontend
   ./build.sh
   ```

2. **Deploy to Netlify**
   ```bash
   cd build
   netlify deploy --prod
   ```

3. **Configure Environment Variables in Netlify Dashboard**
   - Add `API_URL` pointing to your backend URL

### Option 2: Vercel Deployment

1. **Install Vercel CLI**
   ```bash
   npm install -g vercel
   ```

2. **Deploy to Vercel**
   ```bash
   cd frontend
   vercel --prod
   ```

### Option 3: AWS S3 + CloudFront

1. **Build Frontend**
   ```bash
   cd frontend
   ./build.sh
   ```

2. **Deploy to S3**
   ```bash
   aws s3 sync build/ s3://your-bucket-name --delete
   ```

3. **Configure CloudFront**
   - Create distribution pointing to S3 bucket
   - Set up custom domain if needed

## Environment Configuration

Proper environment configuration is crucial for a secure production deployment:

1. **Generate Secure JWT Secret**
   ```bash
   node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
   ```

2. **Required Environment Variables**
   - `NODE_ENV=production`
   - `PORT=5000` (or provided by platform)
   - `MONGODB_URI=your-mongodb-connection-string`
   - `JWT_SECRET=your-secure-jwt-secret`
   - `FRONTEND_URL=https://your-frontend-url.com`
   - `RATE_LIMIT_WINDOW_MS=900000`
   - `RATE_LIMIT_MAX_REQUESTS=100`

3. **Platform-Specific Configuration**
   - See [PRODUCTION_ENV_CONFIG.md](./PRODUCTION_ENV_CONFIG.md) for details

## Continuous Integration/Deployment

We've set up GitHub Actions for CI/CD:

1. **Required Secrets in GitHub Repository**
   - `HEROKU_API_KEY`: Your Heroku API key
   - `HEROKU_EMAIL`: Your Heroku account email
   - `MONGODB_URI`: Your MongoDB Atlas connection string
   - `API_URL`: Your backend API URL
   - `NETLIFY_AUTH_TOKEN`: Your Netlify authentication token
   - `NETLIFY_SITE_ID`: Your Netlify site ID

2. **Workflow**
   - On push to main/master:
     - Tests are run
     - Backend is deployed to Heroku
     - Frontend is deployed to Netlify

3. **Manual Deployment**
   - Use the provided `deploy.sh` script:
     ```bash
     ./deploy.sh
     ```

## Post-Deployment Verification

After deployment, verify that:

1. **Backend API is accessible**
   - Test endpoint: `https://your-backend-url.com/`
   - Should return a welcome message

2. **Frontend is loading correctly**
   - Visit your frontend URL
   - Check browser console for errors

3. **Authentication works**
   - Try registering a new user
   - Try logging in

4. **Games are playable**
   - Test each game functionality

5. **Database is connected**
   - Check logs for database connection success
   - Verify data is being saved correctly

## Troubleshooting

### Common Issues and Solutions

1. **Backend Connection Issues**
   - Check CORS configuration
   - Verify MongoDB connection string
   - Check Heroku logs: `heroku logs --tail`

2. **Frontend API Connection Issues**
   - Verify API_URL environment variable
   - Check browser console for CORS errors
   - Ensure backend URL is correct

3. **Database Connection Failures**
   - Verify network access settings in MongoDB Atlas
   - Check username/password in connection string
   - Ensure IP whitelist includes deployment servers

4. **Authentication Problems**
   - Verify JWT_SECRET is set correctly
   - Check token expiration settings
   - Clear browser cookies and local storage

5. **Deployment Failures**
   - Check platform-specific logs
   - Verify environment variables
   - Check for build errors in CI/CD logs

For additional help, refer to platform-specific documentation:
- [Heroku Dev Center](https://devcenter.heroku.com/)
- [Netlify Docs](https://docs.netlify.com/)
- [MongoDB Atlas Documentation](https://docs.atlas.mongodb.com/)

## Security Considerations

1. **Always use HTTPS** for production deployments
2. **Rotate JWT secrets** periodically
3. **Enable rate limiting** to prevent abuse
4. **Implement proper CORS policies**
5. **Keep dependencies updated** to patch security vulnerabilities
6. **Monitor application logs** for suspicious activity
7. **Perform regular backups** of your database
8. **Use environment variables** for all sensitive information
9. **Implement input validation** on all API endpoints