# Deployment Guide

This guide covers deploying the Rural Games Platform to various cloud platforms.

## 🌐 Deployment Options

### 1. Heroku (Recommended for Beginners)

#### Prerequisites
- Heroku account
- Heroku CLI installed
- Git

#### Backend Deployment

1. **Prepare Backend**
```bash
cd backend
```

2. **Create Heroku App**
```bash
heroku create your-rural-games-api
```

3. **Set Environment Variables**
```bash
heroku config:set NODE_ENV=production
heroku config:set MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/rural-games
heroku config:set JWT_SECRET=your-super-secure-jwt-secret-key
heroku config:set FRONTEND_URL=https://your-frontend-url.com
```

4. **Add MongoDB Atlas**
- Create a free MongoDB Atlas account
- Create a cluster
- Get the connection string
- Set it as MONGODB_URI

5. **Deploy**
```bash
git add .
git commit -m "Deploy to Heroku"
git push heroku main
```

6. **Verify Deployment**
```bash
heroku open
heroku logs --tail
```

#### Frontend Deployment

1. **Build Frontend**
```bash
cd frontend
# Update API_BASE_URL in src/utils/api.js to your Heroku backend URL
npm run build
```

2. **Deploy to Vercel**
```bash
npm i -g vercel
vercel --prod
```

### 2. AWS (Production-Ready)

#### Backend (EC2 + Elastic Beanstalk)

1. **Create Elastic Beanstalk Application**
```bash
cd backend
eb init rural-games-api
eb create production
```

2. **Configure Environment**
```bash
eb setenv NODE_ENV=production
eb setenv MONGODB_URI=your-mongodb-uri
eb setenv JWT_SECRET=your-jwt-secret
eb setenv FRONTEND_URL=https://your-domain.com
```

3. **Deploy**
```bash
eb deploy
```

#### Frontend (S3 + CloudFront)

1. **Build and Deploy to S3**
```bash
cd frontend
npm run build
aws s3 sync build/ s3://your-bucket-name --delete
```

2. **Configure CloudFront**
- Create CloudFront distribution
- Set S3 bucket as origin
- Configure custom domain

### 3. Google Cloud Platform

#### Backend (Cloud Run)

1. **Containerize Backend**
```dockerfile
# Dockerfile
FROM node:16-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 5000
CMD ["npm", "start"]
```

2. **Build and Deploy**
```bash
cd backend
gcloud builds submit --tag gcr.io/PROJECT-ID/rural-games-api
gcloud run deploy --image gcr.io/PROJECT-ID/rural-games-api --platform managed
```

#### Frontend (Firebase Hosting)

1. **Install Firebase CLI**
```bash
npm install -g firebase-tools
```

2. **Initialize Firebase**
```bash
cd frontend
firebase init hosting
```

3. **Deploy**
```bash
firebase deploy --only hosting
```

### 4. DigitalOcean

#### Backend (Droplet)

1. **Create Droplet**
- Choose Ubuntu 20.04
- Select appropriate size
- Add SSH keys

2. **Setup Server**
```bash
ssh root@your-droplet-ip
apt update && apt upgrade -y
apt install -y nodejs npm mongodb git
git clone <your-repo>
cd rural-games-platform/backend
npm install
pm2 start server.js
```

3. **Setup Nginx Reverse Proxy**
```nginx
server {
    listen 80;
    server_name your-domain.com;
    location /api {
        proxy_pass http://localhost:5000;
    }
    location / {
        proxy_pass http://localhost:3000;
    }
}
```

## 🔧 Environment Configuration

### Production Environment Variables

```bash
# Server
NODE_ENV=production
PORT=5000

# Database
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/rural-games

# Security
JWT_SECRET=your-very-secure-jwt-secret-key-here
CORS_ORIGIN=https://your-domain.com

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

### Security Best Practices

1. **Use HTTPS Everywhere**
```bash
# Let's Encrypt for free SSL
certbot --nginx -d your-domain.com
```

2. **Secure JWT Secret**
```bash
# Generate strong secret
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

3. **Database Security**
- Use MongoDB Atlas with IP whitelisting
- Enable authentication
- Use connection string with SSL

4. **Environment Variables**
- Never commit secrets to Git
- Use platform-specific secret management
- Rotate secrets regularly

## 📊 Monitoring & Logging

### Application Monitoring

1. **Set up Monitoring**
```javascript
// Add to backend/server.js
const morgan = require('morgan');
app.use(morgan('combined'));
```

2. **Error Tracking**
```javascript
// Sentry integration
const Sentry = require('@sentry/node');
Sentry.init({ dsn: 'your-sentry-dsn' });
```

3. **Performance Monitoring**
```javascript
// PM2 for process management
npm install -g pm2
pm2 start server.js --name rural-games-api
pm2 monit
```

### Health Checks

1. **Add Health Endpoint**
```javascript
// backend/routes/health.js
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});
```

2. **Database Health Check**
```javascript
const healthCheck = async () => {
  try {
    await mongoose.connection.db.admin().ping();
    return { database: 'connected' };
  } catch (error) {
    return { database: 'disconnected', error: error.message };
  }
};
```

## 🔄 CI/CD Pipeline

### GitHub Actions

1. **Create Workflow File**
```yaml
# .github/workflows/deploy.yml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
        with:
          node-version: '16'
      - run: npm test

  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Deploy to Heroku
        uses: akhileshns/heroku-deploy@v3.12.12
        with:
          heroku_api_key: ${{secrets.HEROKU_API_KEY}}
          heroku_app_name: ${{secrets.HEROKU_APP_NAME}}
          heroku_email: ${{secrets.HEROKU_EMAIL}}
```

2. **Set Repository Secrets**
- `HEROKU_API_KEY`
- `HEROKU_APP_NAME`
- `HEROKU_EMAIL`

## 🚀 Performance Optimization

### Backend Optimization

1. **Enable Compression**
```javascript
const compression = require('compression');
app.use(compression());
```

2. **Cache Static Assets**
```javascript
const express = require('express');
app.use('/static', express.static('public', {
  maxAge: '1y'
}));
```

3. **Database Indexing**
```javascript
// Add to models
gameSchema.index({ category: 1, difficulty: 1 });
scoreSchema.index({ user: 1, game: 1, score: -1 });
```

### Frontend Optimization

1. **Minify CSS/JS**
```bash
npm run build
```

2. **Enable Gzip Compression**
```nginx
# Nginx configuration
gzip on;
gzip_types text/plain text/css application/json application/javascript;
```

3. **CDN for Static Assets**
```javascript
// Use CDN for fonts, images, etc.
const CDN_URL = 'https://cdn.your-domain.com';
```

## 🔒 Security Checklist

- [ ] HTTPS enabled
- [ ] Environment variables secured
- [ ] JWT secrets strong
- [ ] Rate limiting enabled
- [ ] CORS configured properly
- [ ] Input validation implemented
- [ ] Password hashing with bcrypt
- [ ] Database access restricted
- [ ] Regular security updates
- [ ] Error messages don't leak information
- [ ] Log monitoring enabled
- [ ] Backup strategy implemented

## 🆘 Troubleshooting

### Common Issues

1. **MongoDB Connection Issues**
```bash
# Check connection string format
mongo "mongodb+srv://username:password@cluster.mongodb.net/rural-games"
```

2. **CORS Errors**
```javascript
// Ensure FRONTEND_URL matches exactly
const corsOptions = {
  origin: process.env.FRONTEND_URL,
  credentials: true
};
```

3. **Memory Issues**
```bash
# Increase Node.js memory limit
node --max-old-space-size=4096 server.js
```

4. **Port Already in Use**
```bash
# Find and kill process
lsof -ti:5000 | xargs kill -9
```

### Debugging Commands

```bash
# Check logs
heroku logs --tail
pm2 logs

# Monitor performance
pm2 monit
htop

# Network debugging
curl -I https://your-domain.com/api/health
```

## 📈 Scaling Considerations

1. **Horizontal Scaling**
- Load balancer configuration
- Multiple server instances
- Database read replicas

2. **Caching Strategy**
- Redis for session storage
- CDN for static assets
- Application-level caching

3. **Database Optimization**
- Proper indexing
- Connection pooling
- Query optimization

This deployment guide covers the most common deployment scenarios. Choose the option that best fits your requirements and budget.