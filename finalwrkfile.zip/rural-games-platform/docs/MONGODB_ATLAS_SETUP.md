# MongoDB Atlas Setup Guide

This guide will help you set up a MongoDB Atlas database for your Rural Games Platform.

## 1. Create a MongoDB Atlas Account

1. Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) and click "Try Free"
2. Sign up with your email or use Google/GitHub authentication
3. Complete the registration process

## 2. Create a New Cluster

1. After logging in, click "Build a Database"
2. Choose the "FREE" shared cluster option
3. Select your preferred cloud provider (AWS, Google Cloud, or Azure)
4. Choose a region closest to your users
5. Click "Create Cluster" (this may take a few minutes)

## 3. Set Up Database Access

1. While the cluster is being created, click on "Database Access" in the left sidebar
2. Click "Add New Database User"
3. Choose "Password" as the authentication method
4. Enter a username and a secure password (save these credentials)
5. Under "Database User Privileges", select "Atlas admin"
6. Click "Add User"

## 4. Configure Network Access

1. Click on "Network Access" in the left sidebar
2. Click "Add IP Address"
3. For development, you can choose "Allow Access from Anywhere" (not recommended for high-security applications)
4. For production, add specific IP addresses of your servers
5. Click "Confirm"

## 5. Get Your Connection String

1. Once your cluster is ready, click "Connect"
2. Select "Connect your application"
3. Choose "Node.js" as your driver and the appropriate version
4. Copy the connection string
5. Replace `<password>` with your database user's password
6. Replace `myFirstDatabase` with your preferred database name (e.g., `rural-games-platform`)

Your connection string should look like:
```
mongodb+srv://username:password@cluster0.mongodb.net/rural-games-platform?retryWrites=true&w=majority
```

## 6. Initialize Your Database

After setting up your MongoDB Atlas cluster, you can initialize your database with the sample data:

1. Update the `.env` file in your backend directory with your MongoDB Atlas connection string:
   ```
   MONGODB_URI=mongodb+srv://username:password@cluster0.mongodb.net/rural-games-platform?retryWrites=true&w=majority
   ```

2. Run the database initialization script:
   ```bash
   node database/init.js
   ```

## 7. Security Best Practices

- Never commit your MongoDB connection string to Git
- Use environment variables to store sensitive information
- Regularly rotate your database user passwords
- Limit network access to specific IP addresses when possible
- Enable MongoDB Atlas security features like IP whitelisting and VPC peering
- Monitor database access logs regularly

Your MongoDB Atlas database is now ready to use with your Rural Games Platform!