# Docker Deployment Guide for Rural Games Platform

This guide provides step-by-step instructions for deploying the Rural Games Platform using Docker and Docker Compose.

## Prerequisites

- [Docker](https://docs.docker.com/get-docker/) installed
- [Docker Compose](https://docs.docker.com/compose/install/) installed
- Git installed

## Local Deployment with Docker Compose

### 1. Clone the Repository

```bash
git clone <repository-url>
cd rural-games-platform
```

### 2. Configure Environment Variables

The docker-compose.yml file includes default environment variables, but for production, you should modify them:

```bash
# Create a .env file in the project root
cat > .env << EOL
NODE_ENV=production
PORT=5000
MONGODB_URI=mongodb://mongodb:27017/rural-games-platform
JWT_SECRET=$(openssl rand -hex 32)
JWT_EXPIRE=7d
FRONTEND_URL=https://your-frontend-domain.com
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
EOL
```

### 3. Build and Start the Containers

```bash
docker-compose up -d --build
```

This command will:
- Build the backend Docker image
- Start MongoDB container
- Start the backend container
- Start the frontend container with Nginx

### 4. Initialize the Database

```bash
# Execute the initialization script in the backend container
docker-compose exec backend node /app/database/init.js
```

### 5. Access the Application

- Frontend: http://localhost:3000
- Backend API: http://localhost:5000

### 6. Stop the Containers

```bash
docker-compose down
```

## Production Deployment

For production deployment, additional steps are recommended:

### 1. Use Docker Swarm or Kubernetes

For high availability and better orchestration:

```bash
# Initialize Docker Swarm
docker swarm init

# Deploy as a stack
docker stack deploy -c docker-compose.yml rural-games
```

### 2. Use Docker Secrets for Sensitive Information

```bash
# Create secrets
echo "your-super-secure-jwt-secret" | docker secret create jwt_secret -
echo "mongodb://user:password@mongodb:27017/rural-games" | docker secret create mongodb_uri -

# Update docker-compose.yml to use secrets
```

### 3. Set Up Persistent Volumes

Ensure your MongoDB data persists across deployments:

```yaml
volumes:
  mongodb_data:
    driver: local
    driver_opts:
      type: 'none'
      o: 'bind'
      device: '/path/on/host/mongodb-data'
```

### 4. Configure SSL/TLS

For production, always use HTTPS:

1. Update the Nginx configuration to include SSL certificates
2. Use Let's Encrypt for free SSL certificates
3. Configure SSL termination

Example Nginx SSL configuration:

```nginx
server {
    listen 443 ssl;
    server_name your-domain.com;
    
    ssl_certificate /etc/nginx/ssl/fullchain.pem;
    ssl_certificate_key /etc/nginx/ssl/privkey.pem;
    
    # SSL settings
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
    ssl_session_timeout 10m;
    ssl_session_cache shared:SSL:10m;
    
    # Rest of your configuration...
}

# Redirect HTTP to HTTPS
server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$host$request_uri;
}
```

### 5. Set Up Monitoring and Logging

```bash
# Add Prometheus and Grafana for monitoring
docker-compose -f docker-compose.yml -f docker-compose.monitoring.yml up -d

# Add ELK stack for logging
docker-compose -f docker-compose.yml -f docker-compose.logging.yml up -d
```

## Deployment to Cloud Providers

### AWS ECS (Elastic Container Service)

1. Push your Docker images to Amazon ECR:

```bash
# Create ECR repository
aws ecr create-repository --repository-name rural-games-backend

# Login to ECR
aws ecr get-login-password | docker login --username AWS --password-stdin <your-aws-account-id>.dkr.ecr.<region>.amazonaws.com

# Tag and push image
docker tag rural-games-backend:latest <your-aws-account-id>.dkr.ecr.<region>.amazonaws.com/rural-games-backend:latest
docker push <your-aws-account-id>.dkr.ecr.<region>.amazonaws.com/rural-games-backend:latest
```

2. Create an ECS cluster and task definition
3. Configure an ECS service with load balancing

### Google Cloud Run

1. Push your Docker images to Google Container Registry:

```bash
# Configure Docker for GCR
gcloud auth configure-docker

# Tag and push image
docker tag rural-games-backend:latest gcr.io/<your-project-id>/rural-games-backend:latest
docker push gcr.io/<your-project-id>/rural-games-backend:latest
```

2. Deploy to Cloud Run:

```bash
gcloud run deploy rural-games-backend \
  --image gcr.io/<your-project-id>/rural-games-backend:latest \
  --platform managed \
  --allow-unauthenticated \
  --region us-central1 \
  --set-env-vars="NODE_ENV=production,JWT_SECRET=your-secret,FRONTEND_URL=https://your-frontend-url.com"
```

### DigitalOcean App Platform

1. Push your Docker images to DigitalOcean Container Registry:

```bash
# Create registry
doctl registry create rural-games

# Login to registry
doctl registry login

# Tag and push image
docker tag rural-games-backend:latest registry.digitalocean.com/<your-registry-name>/rural-games-backend:latest
docker push registry.digitalocean.com/<your-registry-name>/rural-games-backend:latest
```

2. Create an App Platform app using the DigitalOcean dashboard or CLI

## Troubleshooting

### Common Issues

1. **Container fails to start**
   - Check logs: `docker-compose logs backend`
   - Verify environment variables are set correctly
   - Ensure MongoDB is running and accessible

2. **MongoDB connection issues**
   - Check if MongoDB container is running: `docker ps`
   - Verify the connection string in environment variables
   - Check network connectivity between containers

3. **Frontend cannot connect to backend**
   - Verify the API_URL environment variable
   - Check Nginx configuration
   - Ensure CORS is properly configured

4. **Performance issues**
   - Check container resource limits
   - Consider scaling with Docker Swarm or Kubernetes
   - Monitor container metrics with Docker stats

### Useful Docker Commands

```bash
# View running containers
docker ps

# View container logs
docker logs <container-id>

# Execute command in container
docker exec -it <container-id> /bin/sh

# Check container resource usage
docker stats

# Restart a container
docker restart <container-id>
```

## Security Best Practices

1. **Use non-root users** in your Dockerfiles:
   ```dockerfile
   RUN addgroup -S appgroup && adduser -S appuser -G appgroup
   USER appuser
   ```

2. **Scan images for vulnerabilities**:
   ```bash
   docker scan rural-games-backend:latest
   ```

3. **Use multi-stage builds** to reduce image size:
   ```dockerfile
   # Build stage
   FROM node:18-alpine AS build
   WORKDIR /app
   COPY package*.json ./
   RUN npm ci
   COPY . .
   
   # Production stage
   FROM node:18-alpine
   WORKDIR /app
   COPY --from=build /app .
   EXPOSE 5000
   CMD ["node", "server.js"]
   ```

4. **Never hardcode secrets** in Docker images
5. **Regularly update base images** to patch security vulnerabilities
6. **Limit container capabilities** using security options