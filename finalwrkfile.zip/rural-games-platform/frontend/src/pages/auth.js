// Authentication page handlers
class AuthPage {
  constructor() {
    this.init();
  }

  init() {
    this.setupFormValidation();
    this.setupPasswordToggle();
  }

  setupFormValidation() {
    // Real-time validation
    const inputs = document.querySelectorAll('input[required]');
    inputs.forEach(input => {
      input.addEventListener('blur', () => {
        this.validateField(input);
      });

      input.addEventListener('input', () => {
        if (input.classList.contains('error')) {
          this.validateField(input);
        }
      });
    });
  }

  validateField(input) {
    const errorElement = input.parentElement.querySelector('.form-error');
    let isValid = true;
    let errorMessage = '';

    // Clear previous error
    if (errorElement) {
      errorElement.textContent = '';
    }
    input.classList.remove('error');

    // Check if empty
    if (!input.value.trim()) {
      isValid = false;
      errorMessage = 'This field is required';
    } else {
      // Specific validations based on input type
      switch (input.type) {
        case 'email':
          if (!ui.isValidEmail(input.value)) {
            isValid = false;
            errorMessage = 'Please enter a valid email address';
          }
          break;
        case 'password':
          if (input.value.length < 6) {
            isValid = false;
            errorMessage = 'Password must be at least 6 characters long';
          }
          if (input.id === 'signupPassword' && !this.isStrongPassword(input.value)) {
            isValid = false;
            errorMessage = 'Password should contain uppercase, lowercase, and numbers';
          }
          break;
        case 'text':
          if (input.id === 'signupUsername') {
            if (input.value.length < 3) {
              isValid = false;
              errorMessage = 'Username must be at least 3 characters long';
            }
            if (!/^[a-zA-Z0-9_]+$/.test(input.value)) {
              isValid = false;
              errorMessage = 'Username can only contain letters, numbers, and underscores';
            }
          }
          break;
      }
    }

    if (!isValid) {
      if (errorElement) {
        errorElement.textContent = errorMessage;
      }
      input.classList.add('error');
    }

    return isValid;
  }

  isStrongPassword(password) {
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    return hasUpperCase && hasLowerCase && hasNumbers;
  }

  setupPasswordToggle() {
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    passwordInputs.forEach(input => {
      const wrapper = document.createElement('div');
      wrapper.style.position = 'relative';
      
      input.parentNode.insertBefore(wrapper, input);
      wrapper.appendChild(input);
      
      const toggle = document.createElement('button');
      toggle.type = 'button';
      toggle.innerHTML = '<i class="fas fa-eye"></i>';
      toggle.style.cssText = `
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        cursor: pointer;
        color: #666;
        padding: 5px;
      `;
      
      toggle.addEventListener('click', () => {
        const type = input.type === 'password' ? 'text' : 'password';
        input.type = type;
        toggle.innerHTML = type === 'password' ? '<i class="fas fa-eye"></i>' : '<i class="fas fa-eye-slash"></i>';
      });
      
      wrapper.appendChild(toggle);
    });
  }
}

// Initialize auth page when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('login-page') || document.getElementById('signup-page')) {
    new AuthPage();
  }
});