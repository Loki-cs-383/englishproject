// Main Application Entry Point
class App {
  constructor() {
    this.version = '1.0.0';
    this.isInitialized = false;
    this.init();
  }

  // Initialize application
  async init() {
    try {
      console.log(`🎮 Rural Games Platform v${this.version} starting...`);
      
      // Initialize UI components
      this.initializeUI();
      
      // Initialize services
      await this.initializeServices();
      
      // Setup global error handling
      this.setupErrorHandling();
      
      // Setup service worker (if available)
      this.setupServiceWorker();
      
      // Check authentication status
      await this.checkAuthStatus();
      
      // Initialize game modules
      this.initializeGameModules();
      
      // Setup keyboard shortcuts
      this.setupKeyboardShortcuts();
      
      // Mark as initialized
      this.isInitialized = true;
      
      console.log('✅ Application initialized successfully');
      
      // Show welcome message
      this.showWelcomeMessage();
      
    } catch (error) {
      console.error('❌ Failed to initialize application:', error);
      showToast('Failed to initialize application. Please refresh the page.', 'error');
    }
  }

  // Initialize UI components
  initializeUI() {
    // Initialize modal close handlers
    ui.initModalClose();
    
    // Setup smooth scrolling
    this.setupSmoothScrolling();
    
    // Setup responsive navigation
    this.setupResponsiveNavigation();
    
    // Add page transitions
    this.addPageTransitions();
  }

  // Initialize services
  async initializeServices() {
    // Check if backend is available
    try {
      const response = await fetch(`${API_BASE_URL.replace('/api', '')}`);
      if (!response.ok) {
        console.warn('⚠️ Backend server is not available');
        showToast('Backend server is not available. Some features may be limited.', 'warning');
      }
    } catch (error) {
      console.warn('⚠️ Cannot connect to backend server:', error);
      showToast('Cannot connect to backend server. Running in offline mode.', 'info');
    }
  }

  // Setup global error handling
  setupErrorHandling() {
    // Handle uncaught errors
    window.addEventListener('error', (event) => {
      console.error('Global error:', event.error);
      showToast('An unexpected error occurred. Please refresh the page.', 'error');
    });

    // Handle unhandled promise rejections
    window.addEventListener('unhandledrejection', (event) => {
      console.error('Unhandled promise rejection:', event.reason);
      showToast('An unexpected error occurred. Please try again.', 'error');
    });
  }

  // Setup service worker for PWA capabilities
  setupServiceWorker() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .then(registration => {
          console.log('✅ Service Worker registered:', registration);
        })
        .catch(error => {
          console.log('⚠️ Service Worker registration failed:', error);
        });
    }
  }

  // Check authentication status
  async checkAuthStatus() {
    if (auth.isLoggedIn()) {
      try {
        await auth.getCurrentUser();
        console.log('✅ User is authenticated:', auth.getUser().username);
      } catch (error) {
        console.log('⚠️ Token validation failed, user may need to login again');
      }
    }
  }

  // Initialize game modules
  initializeGameModules() {
    // Initialize game modules if they exist
    const gameModules = ['ticTacToe', 'snakeLadder', 'khoKho', 'gilliDanda'];
    
    gameModules.forEach(moduleName => {
      if (window[moduleName]) {
        try {
          window[moduleName].init();
          console.log(`✅ ${moduleName} module initialized`);
        } catch (error) {
          console.error(`❌ Failed to initialize ${moduleName} module:`, error);
        }
      }
    });
  }

  // Setup keyboard shortcuts
  setupKeyboardShortcuts() {
    document.addEventListener('keydown', (event) => {
      // Ctrl/Cmd + K for search
      if ((event.ctrlKey || event.metaKey) && event.key === 'k') {
        event.preventDefault();
        const searchInput = document.getElementById('gameSearch');
        if (searchInput) {
          searchInput.focus();
        }
      }

      // Escape to close modals
      if (event.key === 'Escape') {
        const activeModal = document.querySelector('.modal.active');
        if (activeModal) {
          hideModal(activeModal.id);
        }
      }

      // Alt + H for home
      if (event.altKey && event.key === 'h') {
        event.preventDefault();
        showPage('home');
      }

      // Alt + G for games
      if (event.altKey && event.key === 'g') {
        event.preventDefault();
        showPage('games');
      }

      // Alt + L for leaderboard
      if (event.altKey && event.key === 'l') {
        event.preventDefault();
        showPage('leaderboard');
      }
    });
  }

  // Setup smooth scrolling
  setupSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        if (href !== '#' && !href.includes('page')) {
          e.preventDefault();
          const target = document.querySelector(href);
          if (target) {
            target.scrollIntoView({
              behavior: 'smooth',
              block: 'start'
            });
          }
        }
      });
    });
  }

  // Setup responsive navigation
  setupResponsiveNavigation() {
    // Handle window resize
    let resizeTimer;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => {
        // Adjust layout for mobile/desktop
        this.adjustLayout();
      }, 250);
    });

    // Initial layout adjustment
    this.adjustLayout();
  }

  // Adjust layout based on screen size
  adjustLayout() {
    const isMobile = window.innerWidth <= 768;
    
    // Add mobile class to body
    if (isMobile) {
      document.body.classList.add('mobile');
    } else {
      document.body.classList.remove('mobile');
    }
  }

  // Add page transitions
  addPageTransitions() {
    const style = document.createElement('style');
    style.textContent = `
      .page {
        transition: opacity 0.3s ease, transform 0.3s ease;
      }
      
      .page.active {
        opacity: 1;
        transform: translateX(0);
      }
      
      .page:not(.active) {
        opacity: 0;
        transform: translateX(20px);
      }
    `;
    document.head.appendChild(style);
  }

  // Show welcome message
  showWelcomeMessage() {
    const user = auth.getUser();
    if (user) {
      showToast(`Welcome back, ${user.username}!`, 'success');
    } else {
      // Show welcome message for new visitors
      const visitCount = localStorage.getItem('visitCount') || 0;
      localStorage.setItem('visitCount', parseInt(visitCount) + 1);
      
      if (parseInt(visitCount) === 0) {
        setTimeout(() => {
          showToast('Welcome to Rural Games Platform! 🎮', 'info', 5000);
        }, 1000);
      }
    }
  }

  // Get app information
  getInfo() {
    return {
      name: 'Rural Games Platform',
      version: this.version,
      isInitialized: this.isInitialized,
      userAgent: navigator.userAgent,
      isOnline: navigator.onLine,
      isMobile: /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
    };
  }

  // Show app information (for debugging)
  showInfo() {
    console.table(this.getInfo());
    return this.getInfo();
  }

  // Refresh application state
  async refresh() {
    try {
      showLoading(true);
      
      // Refresh current user data
      if (auth.isLoggedIn()) {
        await auth.getCurrentUser();
      }
      
      // Reload current page content
      navigation.onPageChange(navigation.currentPage);
      
      hideLoading();
      showToast('Application refreshed', 'success');
      
    } catch (error) {
      hideLoading();
      console.error('Error refreshing application:', error);
      showToast('Failed to refresh application', 'error');
    }
  }

  // Handle online/offline status
  setupNetworkStatus() {
    window.addEventListener('online', () => {
      showToast('You are back online!', 'success');
    });

    window.addEventListener('offline', () => {
      showToast('You are offline. Some features may be limited.', 'warning');
    });
  }
}

// Create and initialize the application
const app = new App();

// Make app globally available
window.app = app;

// Global functions
window.closeGameModal = () => hideModal('gameModal');

// Initialize everything when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    console.log('🎮 DOM ready, application starting...');
  });
} else {
  console.log('🎮 DOM already loaded, application starting...');
}

// Export for module usage
export default app;