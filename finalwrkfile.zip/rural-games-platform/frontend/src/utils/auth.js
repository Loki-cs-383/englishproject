// Authentication utilities
class Auth {
  constructor() {
    this.user = null;
    this.isAuthenticated = false;
    this.init();
  }

  // Initialize authentication state
  init() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');

    if (token && user) {
      this.token = token;
      this.user = JSON.parse(user);
      this.isAuthenticated = true;
      this.updateUI();
    }
  }

  // Update UI based on authentication state
  updateUI() {
    const navUser = document.getElementById('navUser');
    const loginBtn = document.querySelector('.login-btn');
    const signupBtn = document.querySelector('.signup-btn');

    if (!navUser) return;

    if (this.isAuthenticated && this.user) {
      // Show user menu
      navUser.innerHTML = `
        <div class="user-menu">
          <div class="user-avatar" onclick="auth.toggleUserMenu()">
            ${this.user.username.charAt(0).toUpperCase()}
          </div>
          <div class="user-dropdown" id="userDropdown">
            <a href="#" onclick="auth.showProfile(); return false;">
              <i class="fas fa-user"></i> Profile
            </a>
            <a href="#" onclick="auth.showDashboard(); return false;">
              <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a href="#" onclick="auth.logout(); return false;">
              <i class="fas fa-sign-out-alt"></i> Logout
            </a>
          </div>
        </div>
      `;
    } else {
      // Show login/signup buttons
      navUser.innerHTML = `
        <button class="btn btn-outline login-btn" onclick="showPage('login')">Login</button>
        <button class="btn btn-primary signup-btn" onclick="showPage('signup')">Sign Up</button>
      `;
    }
  }

  // Toggle user dropdown menu
  toggleUserMenu() {
    const dropdown = document.getElementById('userDropdown');
    if (dropdown) {
      dropdown.classList.toggle('active');
    }

    // Close dropdown when clicking outside
    document.addEventListener('click', this.closeDropdown);
  }

  // Close dropdown when clicking outside
  closeDropdown(event) {
    const dropdown = document.getElementById('userDropdown');
    const userMenu = document.querySelector('.user-menu');
    
    if (dropdown && !userMenu.contains(event.target)) {
      dropdown.classList.remove('active');
      document.removeEventListener('click', this.closeDropdown);
    }
  }

  // Register new user
  async register(userData) {
    try {
      showLoading(true);
      const response = await api.register(userData);
      
      this.token = response.token;
      this.user = response.user;
      this.isAuthenticated = true;
      
      localStorage.setItem('token', response.token);
      localStorage.setItem('user', JSON.stringify(response.user));
      
      this.updateUI();
      hideLoading();
      
      showToast('Registration successful! Welcome to Rural Games!', 'success');
      showPage('home');
      
      return response;
    } catch (error) {
      hideLoading();
      showToast(error.message || 'Registration failed', 'error');
      throw error;
    }
  }

  // Login user
  async login(credentials) {
    try {
      showLoading(true);
      const response = await api.login(credentials);
      
      this.token = response.token;
      this.user = response.user;
      this.isAuthenticated = true;
      
      localStorage.setItem('token', response.token);
      localStorage.setItem('user', JSON.stringify(response.user));
      
      this.updateUI();
      hideLoading();
      
      showToast('Login successful! Welcome back!', 'success');
      showPage('home');
      
      return response;
    } catch (error) {
      hideLoading();
      showToast(error.message || 'Login failed', 'error');
      throw error;
    }
  }

  // Logout user
  async logout() {
    try {
      if (this.token) {
        await api.logout();
      }
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      this.token = null;
      this.user = null;
      this.isAuthenticated = false;
      
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      
      this.updateUI();
      showToast('Logged out successfully', 'info');
      showPage('home');
    }
  }

  // Get current user
  async getCurrentUser() {
    try {
      const response = await api.getCurrentUser();
      this.user = response.user;
      localStorage.setItem('user', JSON.stringify(this.user));
      return response;
    } catch (error) {
      console.error('Get current user error:', error);
      // If token is invalid, logout
      if (error.message.includes('token')) {
        await this.logout();
      }
      throw error;
    }
  }

  // Update user profile
  async updateProfile(profileData) {
    try {
      showLoading(true);
      const response = await api.updateProfile(profileData);
      
      this.user = response.user;
      localStorage.setItem('user', JSON.stringify(this.user));
      
      hideLoading();
      showToast('Profile updated successfully!', 'success');
      
      return response;
    } catch (error) {
      hideLoading();
      showToast(error.message || 'Profile update failed', 'error');
      throw error;
    }
  }

  // Change password
  async changePassword(passwordData) {
    try {
      showLoading(true);
      const response = await api.changePassword(passwordData);
      
      hideLoading();
      showToast('Password changed successfully!', 'success');
      
      return response;
    } catch (error) {
      hideLoading();
      showToast(error.message || 'Password change failed', 'error');
      throw error;
    }
  }

  // Check if user is authenticated
  isLoggedIn() {
    return this.isAuthenticated && this.token;
  }

  // Get user data
  getUser() {
    return this.user;
  }

  // Get token
  getToken() {
    return this.token;
  }

  // Show user profile
  showProfile() {
    // TODO: Implement profile page
    showToast('Profile page coming soon!', 'info');
  }

  // Show user dashboard
  showDashboard() {
    // TODO: Implement dashboard page
    showToast('Dashboard page coming soon!', 'info');
  }

  // Require authentication (redirect to login if not authenticated)
  requireAuth() {
    if (!this.isAuthenticated) {
      showToast('Please login to continue', 'warning');
      showPage('login');
      return false;
    }
    return true;
  }
}

// Create and export auth instance
const auth = new Auth();

// Export for use in other modules
window.auth = auth;