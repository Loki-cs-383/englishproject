// API Configuration
const API_BASE_URL = process.env.API_URL || 'http://localhost:5000/api';

// API Class
class API {
  constructor() {
    this.baseURL = API_BASE_URL;
    this.token = localStorage.getItem('token');
  }

  // Helper method to make HTTP requests
  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    // Add authorization token if available
    if (this.token) {
      config.headers.Authorization = `Bearer ${this.token}`;
    }

    try {
      const response = await fetch(url, config);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Something went wrong');
      }

      return data;
    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  }

  // Authentication endpoints
  async register(userData) {
    return this.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  }

  async login(credentials) {
    const response = await this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
    
    if (response.token) {
      this.token = response.token;
      localStorage.setItem('token', response.token);
      localStorage.setItem('user', JSON.stringify(response.user));
    }
    
    return response;
  }

  async logout() {
    const response = await this.request('/auth/logout', {
      method: 'POST',
    });
    
    this.token = null;
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    
    return response;
  }

  async getCurrentUser() {
    return this.request('/auth/me');
  }

  async updateProfile(profileData) {
    return this.request('/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(profileData),
    });
  }

  async changePassword(passwordData) {
    return this.request('/auth/change-password', {
      method: 'PUT',
      body: JSON.stringify(passwordData),
    });
  }

  // Games endpoints
  async getAllGames(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/games?${queryString}`);
  }

  async getGameById(gameId) {
    return this.request(`/games/${gameId}`);
  }

  async getPopularGames(limit = 10) {
    return this.request(`/games/popular?limit=${limit}`);
  }

  async getGamesByCategory(category, params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/games/category/${category}?${queryString}`);
  }

  async getGameCategories() {
    return this.request('/games/categories');
  }

  async playGame(gameId) {
    return this.request(`/games/${gameId}/play`, {
      method: 'POST',
    });
  }

  async rateGame(gameId, rating) {
    return this.request(`/games/${gameId}/rate`, {
      method: 'POST',
      body: JSON.stringify({ rating }),
    });
  }

  async getGameLeaderboard(gameId, params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/games/${gameId}/leaderboard?${queryString}`);
  }

  async searchGames(query, params = {}) {
    const queryString = new URLSearchParams({ q, ...params }).toString();
    return this.request(`/games/search?${queryString}`);
  }

  // Scores endpoints
  async submitScore(gameId, scoreData) {
    return this.request(`/scores/game/${gameId}`, {
      method: 'POST',
      body: JSON.stringify(scoreData),
    });
  }

  async getUserScores(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/scores/user?${queryString}`);
  }

  async getUserGameHistory(userId, params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/scores/user/${userId}/history?${queryString}`);
  }

  async getUserStatistics(userId) {
    return this.request(`/scores/user/${userId}/statistics`);
  }

  async getGameScores(gameId, params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/scores/game/${gameId}?${queryString}`);
  }

  async getTopScores(gameId, params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/scores/game/${gameId}/top?${queryString}`);
  }

  async deleteScore(scoreId) {
    return this.request(`/scores/${scoreId}`, {
      method: 'DELETE',
    });
  }

  // Users endpoints
  async getUserById(userId) {
    return this.request(`/users/${userId}`);
  }

  async updateAvatar(avatarUrl) {
    return this.request('/users/avatar', {
      method: 'PUT',
      body: JSON.stringify({ avatar: avatarUrl }),
    });
  }

  async searchUsers(query, params = {}) {
    const queryString = new URLSearchParams({ query, ...params }).toString();
    return this.request(`/users/search/${query}?${queryString}`);
  }

  async getGlobalLeaderboard(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/users/leaderboard/global?${queryString}`);
  }
}

// Create and export API instance
const api = new API();

// Export for use in other modules
window.api = api;