// Navigation utilities
class Navigation {
  constructor() {
    this.currentPage = 'home';
    this.pages = document.querySelectorAll('.page');
    this.navLinks = document.querySelectorAll('.nav-link');
    this.init();
  }

  init() {
    this.setupNavigation();
    this.setupMobileMenu();
    this.setupPageHistory();
  }

  // Setup navigation links
  setupNavigation() {
    // Handle nav link clicks
    this.navLinks.forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetPage = link.getAttribute('data-page');
        if (targetPage) {
          this.showPage(targetPage);
        }
      });
    });

    // Handle browser back/forward buttons
    window.addEventListener('popstate', (e) => {
      if (e.state && e.state.page) {
        this.showPage(e.state.page, false);
      }
    });

    // Handle anchor links
    document.addEventListener('click', (e) => {
      if (e.target.tagName === 'A' && e.target.getAttribute('href').startsWith('#')) {
        e.preventDefault();
        const page = e.target.getAttribute('href').substring(1);
        if (page && this.isValidPage(page)) {
          this.showPage(page);
        }
      }
    });
  }

  // Setup mobile menu toggle
  setupMobileMenu() {
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');

    if (navToggle && navMenu) {
      navToggle.addEventListener('click', () => {
        navToggle.classList.toggle('active');
        navMenu.classList.toggle('active');
      });

      // Close menu when clicking on a link
      navMenu.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
          navToggle.classList.remove('active');
          navMenu.classList.remove('active');
        });
      });

      // Close menu when clicking outside
      document.addEventListener('click', (e) => {
        if (!navToggle.contains(e.target) && !navMenu.contains(e.target)) {
          navToggle.classList.remove('active');
          navMenu.classList.remove('active');
        }
      });
    }
  }

  // Setup page history
  setupPageHistory() {
    // Set initial page state
    const initialPage = this.getPageFromURL() || 'home';
    this.showPage(initialPage, false);
  }

  // Show page
  showPage(pageName, addToHistory = true) {
    if (!this.isValidPage(pageName)) {
      console.error(`Invalid page: ${pageName}`);
      return;
    }

    // Hide current page
    if (this.currentPage) {
      const currentPageElement = document.getElementById(`${this.currentPage}-page`);
      if (currentPageElement) {
        currentPageElement.classList.remove('active');
      }
    }

    // Show new page
    const newPageElement = document.getElementById(`${pageName}-page`);
    if (newPageElement) {
      newPageElement.classList.add('active');
    }

    // Update navigation
    this.updateNavigation(pageName);

    // Update current page
    this.currentPage = pageName;

    // Update URL
    if (addToHistory) {
      const url = `#${pageName}`;
      history.pushState({ page: pageName }, '', url);
    }

    // Scroll to top
    window.scrollTo(0, 0);

    // Close mobile menu
    this.closeMobileMenu();

    // Trigger page-specific logic
    this.onPageChange(pageName);
  }

  // Check if page is valid
  isValidPage(pageName) {
    const validPages = ['home', 'games', 'login', 'signup', 'leaderboard', 'about'];
    return validPages.includes(pageName);
  }

  // Update navigation active state
  updateNavigation(pageName) {
    this.navLinks.forEach(link => {
      const linkPage = link.getAttribute('data-page');
      if (linkPage === pageName) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  }

  // Get page from URL hash
  getPageFromURL() {
    const hash = window.location.hash.substring(1);
    return hash || 'home';
  }

  // Close mobile menu
  closeMobileMenu() {
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');

    if (navToggle && navMenu) {
      navToggle.classList.remove('active');
      navMenu.classList.remove('active');
    }
  }

  // Page change event handler
  onPageChange(pageName) {
    // Remove previous page event listeners
    this.removePageEventListeners();

    // Add new page event listeners
    switch (pageName) {
      case 'home':
        this.setupHomePage();
        break;
      case 'games':
        this.setupGamesPage();
        break;
      case 'login':
        this.setupLoginPage();
        break;
      case 'signup':
        this.setupSignupPage();
        break;
      case 'leaderboard':
        this.setupLeaderboardPage();
        break;
      case 'about':
        this.setupAboutPage();
        break;
    }
  }

  // Setup home page
  setupHomePage() {
    this.loadPopularGames();
  }

  // Setup games page
  setupGamesPage() {
    this.loadAllGames();
    this.setupGameFilters();
  }

  // Setup login page
  setupLoginPage() {
    this.setupLoginForm();
  }

  // Setup signup page
  setupSignupPage() {
    this.setupSignupForm();
  }

  // Setup leaderboard page
  setupLeaderboardPage() {
    this.loadLeaderboards();
  }

  // Setup about page
  setupAboutPage() {
    // About page setup if needed
  }

  // Load popular games
  async loadPopularGames() {
    try {
      const container = document.getElementById('popularGamesGrid');
      if (!container) return;

      showLoading(true);
      const response = await api.getPopularGames(4);
      
      container.innerHTML = '';
      response.games.forEach(game => {
        const gameCard = this.createGameCard(game);
        container.appendChild(gameCard);
      });

      hideLoading();
    } catch (error) {
      hideLoading();
      console.error('Error loading popular games:', error);
      showToast('Failed to load popular games', 'error');
    }
  }

  // Load all games
  async loadAllGames() {
    try {
      const container = document.getElementById('gamesGrid');
      if (!container) return;

      showLoading(true);
      const response = await api.getAllGames();
      
      container.innerHTML = '';
      response.games.forEach(game => {
        const gameCard = this.createGameCard(game);
        container.appendChild(gameCard);
      });

      hideLoading();
    } catch (error) {
      hideLoading();
      console.error('Error loading games:', error);
      showToast('Failed to load games', 'error');
    }
  }

  // Create game card element
  createGameCard(game) {
    const card = document.createElement('div');
    card.className = 'game-card animate-on-scroll';
    card.innerHTML = `
      <div class="game-thumbnail">
        <div class="game-icon-large">
          <i class="fas ${this.getGameIcon(game.category)}"></i>
        </div>
      </div>
      <div class="game-info">
        <h3 class="game-title">${game.name}</h3>
        <p class="game-description">${game.description}</p>
        <div class="game-meta">
          <span class="game-category">${game.category}</span>
          <div class="game-difficulty">
            ${this.createDifficultyDots(game.difficulty)}
          </div>
        </div>
        <div class="game-stats">
          <div class="game-stat">
            <i class="fas fa-play"></i>
            <span>${ui.formatNumber(game.popularity.playsCount)}</span>
          </div>
          <div class="game-stat">
            <i class="fas fa-star"></i>
            <span>${game.popularity.rating.toFixed(1)}</span>
          </div>
        </div>
        <div class="game-actions">
          <button class="btn btn-primary" onclick="navigation.playGame('${game._id}')">
            <i class="fas fa-play"></i> Play
          </button>
          <button class="btn btn-outline" onclick="navigation.showGameDetails('${game._id}')">
            <i class="fas fa-info-circle"></i> Details
          </button>
        </div>
      </div>
    `;
    return card;
  }

  // Get game icon based on category
  getGameIcon(category) {
    const icons = {
      board: 'fa-chess-board',
      outdoor: 'fa-running',
      indoor: 'fa-home',
      strategy: 'fa-brain',
      luck: 'fa-dice'
    };
    return icons[category] || 'fa-gamepad';
  }

  // Create difficulty dots
  createDifficultyDots(difficulty) {
    const levels = { easy: 1, medium: 2, hard: 3 };
    const level = levels[difficulty] || 1;
    let dots = '';
    
    for (let i = 1; i <= 3; i++) {
      dots += `<span class="difficulty-dot ${i <= level ? 'active' : ''}"></span>`;
    }
    
    return dots;
  }

  // Setup game filters
  setupGameFilters() {
    const categoryFilter = document.getElementById('categoryFilter');
    const difficultyFilter = document.getElementById('difficultyFilter');
    const searchInput = document.getElementById('gameSearch');

    if (categoryFilter) {
      categoryFilter.addEventListener('change', () => this.filterGames());
    }

    if (difficultyFilter) {
      difficultyFilter.addEventListener('change', () => this.filterGames());
    }

    if (searchInput) {
      searchInput.addEventListener('input', ui.debounce(() => this.filterGames(), 300));
    }
  }

  // Filter games
  async filterGames() {
    const categoryFilter = document.getElementById('categoryFilter');
    const difficultyFilter = document.getElementById('difficultyFilter');
    const searchInput = document.getElementById('gameSearch');

    const params = {};
    if (categoryFilter.value) params.category = categoryFilter.value;
    if (difficultyFilter.value) params.difficulty = difficultyFilter.value;
    if (searchInput.value) {
      try {
        const response = await api.searchGames(searchInput.value, params);
        this.displayFilteredGames(response.games);
        return;
      } catch (error) {
        console.error('Error searching games:', error);
        showToast('Failed to search games', 'error');
        return;
      }
    }

    try {
      const response = await api.getAllGames(params);
      this.displayFilteredGames(response.games);
    } catch (error) {
      console.error('Error filtering games:', error);
      showToast('Failed to filter games', 'error');
    }
  }

  // Display filtered games
  displayFilteredGames(games) {
    const container = document.getElementById('gamesGrid');
    if (!container) return;

    container.innerHTML = '';
    games.forEach(game => {
      const gameCard = this.createGameCard(game);
      container.appendChild(gameCard);
    });
  }

  // Play game
  playGame(gameId) {
    if (!auth.requireAuth()) return;
    
    // Show game modal
    this.showGameModal(gameId);
  }

  // Show game details
  async showGameDetails(gameId) {
    try {
      showLoading(true);
      const response = await api.getGameById(gameId);
      
      // TODO: Show game details modal
      showToast('Game details coming soon!', 'info');
      
      hideLoading();
    } catch (error) {
      hideLoading();
      console.error('Error loading game details:', error);
      showToast('Failed to load game details', 'error');
    }
  }

  // Show game modal
  showGameModal(gameId) {
    // Load game based on type
    this.loadGame(gameId);
    showModal('gameModal');
  }

  // Load game
  async loadGame(gameId) {
    try {
      const response = await api.getGameById(gameId);
      const game = response.game;
      
      const container = document.getElementById('gameContainer');
      if (!container) return;

      // Load appropriate game based on game name
      switch (game.name.toLowerCase().replace(/[^a-z]/g, '')) {
        case 'tictactoe':
          this.loadTicTacToe(game);
          break;
        case 'snake ladder':
        case 'snakeladder':
          this.loadSnakeLadder(game);
          break;
        case 'khokho':
          this.loadKhoKho(game);
          break;
        case 'gillidanda':
          this.loadGilliDanda(game);
          break;
        default:
          container.innerHTML = '<p>Game not available yet</p>';
      }

      // Set modal title
      document.getElementById('gameModalTitle').textContent = game.name;
      
    } catch (error) {
      console.error('Error loading game:', error);
      showToast('Failed to load game', 'error');
    }
  }

  // Load Tic-Tac-Toe game
  loadTicTacToe(game) {
    // This will be implemented in the game module
    if (window.ticTacToe) {
      window.ticTacToe.init(document.getElementById('gameContainer'));
    }
  }

  // Load Snake & Ladder game
  loadSnakeLadder(game) {
    // This will be implemented in the game module
    if (window.snakeLadder) {
      window.snakeLadder.init(document.getElementById('gameContainer'));
    }
  }

  // Load Kho-Kho game
  loadKhoKho(game) {
    // This will be implemented in the game module
    if (window.khoKho) {
      window.khoKho.init(document.getElementById('gameContainer'));
    }
  }

  // Load Gilli Danda game
  loadGilliDanda(game) {
    // This will be implemented in the game module
    if (window.gilliDanda) {
      window.gilliDanda.init(document.getElementById('gameContainer'));
    }
  }

  // Setup login form
  setupLoginForm() {
    const form = document.getElementById('loginForm');
    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        if (!ui.validateForm(form)) return;

        const formData = new FormData(form);
        const credentials = {
          email: formData.get('email'),
          password: formData.get('password')
        };

        try {
          await auth.login(credentials);
        } catch (error) {
          // Error is handled in auth module
        }
      });
    }
  }

  // Setup signup form
  setupSignupForm() {
    const form = document.getElementById('signupForm');
    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        if (!ui.validateForm(form)) return;

        const formData = new FormData(form);
        const userData = {
          username: formData.get('username'),
          email: formData.get('email'),
          password: formData.get('password'),
          firstName: formData.get('firstName'),
          lastName: formData.get('lastName')
        };

        try {
          await auth.register(userData);
        } catch (error) {
          // Error is handled in auth module
        }
      });
    }
  }

  // Load leaderboards
  async loadLeaderboards() {
    // TODO: Implement leaderboard loading
    showToast('Leaderboard coming soon!', 'info');
  }

  // Remove page event listeners
  removePageEventListeners() {
    // Clean up any event listeners from the previous page
    // This prevents memory leaks
  }
}

// Create and export navigation instance
const navigation = new Navigation();

// Global function for page navigation
window.showPage = (pageName) => navigation.showPage(pageName);

// Export for use in other modules
window.navigation = navigation;