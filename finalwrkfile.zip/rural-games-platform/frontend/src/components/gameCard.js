// Game Card Component
class GameCard {
  constructor(game) {
    this.game = game;
  }

  render() {
    const card = document.createElement('div');
    card.className = 'game-card animate-on-scroll';
    card.innerHTML = `
      <div class="game-thumbnail">
        <div class="game-icon-large">
          <i class="fas ${this.getGameIcon()}"></i>
        </div>
      </div>
      <div class="game-info">
        <h3 class="game-title">${this.game.name}</h3>
        <p class="game-description">${this.game.description}</p>
        <div class="game-meta">
          <span class="game-category">${this.game.category}</span>
          <div class="game-difficulty">
            ${this.createDifficultyDots()}
          </div>
        </div>
        <div class="game-stats">
          <div class="game-stat">
            <i class="fas fa-play"></i>
            <span>${ui.formatNumber(this.game.popularity.playsCount)}</span>
          </div>
          <div class="game-stat">
            <i class="fas fa-star"></i>
            <span>${this.game.popularity.rating.toFixed(1)}</span>
          </div>
        </div>
        <div class="game-actions">
          <button class="btn btn-primary" onclick="gameCard.playGame('${this.game._id}')">
            <i class="fas fa-play"></i> Play
          </button>
          <button class="btn btn-outline" onclick="gameCard.showDetails('${this.game._id}')">
            <i class="fas fa-info-circle"></i> Details
          </button>
        </div>
      </div>
    `;

    // Add hover effects
    this.addHoverEffects(card);

    return card;
  }

  getGameIcon() {
    const icons = {
      board: 'fa-chess-board',
      outdoor: 'fa-running',
      indoor: 'fa-home',
      strategy: 'fa-brain',
      luck: 'fa-dice'
    };
    return icons[this.game.category] || 'fa-gamepad';
  }

  createDifficultyDots() {
    const levels = { easy: 1, medium: 2, hard: 3 };
    const level = levels[this.game.difficulty] || 1;
    let dots = '';
    
    for (let i = 1; i <= 3; i++) {
      dots += `<span class="difficulty-dot ${i <= level ? 'active' : ''}"></span>`;
    }
    
    return dots;
  }

  addHoverEffects(card) {
    card.addEventListener('mouseenter', () => {
      card.style.transform = 'translateY(-5px) scale(1.02)';
    });

    card.addEventListener('mouseleave', () => {
      card.style.transform = 'translateY(0) scale(1)';
    });
  }

  playGame(gameId) {
    if (!auth.requireAuth()) return;
    
    // Track game play
    api.playGame(gameId).then(() => {
      console.log('Game play tracked');
    }).catch(error => {
      console.error('Error tracking game play:', error);
    });
    
    // Show game modal
    navigation.showGameModal(gameId);
  }

  showDetails(gameId) {
    // TODO: Implement game details modal
    showToast('Game details coming soon!', 'info');
  }
}

// Export for use in other modules
window.GameCard = GameCard;
window.gameCard = {
  createGameCard: (game) => new GameCard(game).render(),
  playGame: (gameId) => new GameCard({ _id: gameId }).playGame(gameId),
  showDetails: (gameId) => new GameCard({ _id: gameId }).showDetails(gameId)
};