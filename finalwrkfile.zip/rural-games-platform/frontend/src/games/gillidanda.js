// Gilli Danda Game Module
class GilliDanda {
  constructor() {
    this.gameActive = false;
    this.currentScore = 0;
    this.highScore = 0;
    this.attempts = 3;
    this.currentAttempt = 0;
    this.gameMode = 'single-player';
    this.gameStartTime = null;
    this.currentGameId = null;
    this.power = 0;
    this.powerDirection = 1;
    this.powerInterval = null;
    this.gilliFlying = false;
    this.distances = [];
  }

  // Initialize game
  init(container) {
    this.container = container;
    this.gameStartTime = Date.now();
    this.createGameBoard();
    this.resetGame();
  }

  // Create game board HTML
  createGameBoard() {
    this.container.innerHTML = `
      <div class="game-container">
        <div class="game-header">
          <h2 class="game-title">Gilli Danda</h2>
          <div class="game-controls">
            <select id="gameMode" class="game-mode-select">
              <option value="single-player">Single Player</option>
              <option value="practice">Practice Mode</option>
            </select>
            <button class="btn btn-outline" onclick="gillidanda.resetGame()">
              <i class="fas fa-redo"></i> New Game
            </button>
          </div>
        </div>
        
        <div class="game-board">
          <div class="gillidanda-field" id="gillidandaField">
            <div class="gillidanda-ground"></div>
            <div class="gilli" id="gilli"></div>
            <div class="danda" id="danda"></div>
            <div class="power-meter">
              <div class="power-fill" id="powerFill"></div>
            </div>
            <div class="distance-marker" id="distanceMarker"></div>
          </div>
          
          <div class="game-controls-panel">
            <div class="score-section">
              <h3>Score Board</h3>
              <div class="score-display">
                <div class="score-item">
                  <span>Current Score:</span>
                  <span id="currentScore">0</span>
                </div>
                <div class="score-item">
                  <span>High Score:</span>
                  <span id="highScore">0</span>
                </div>
                <div class="score-item">
                  <span>Attempts Left:</span>
                  <span id="attemptsLeft">3</span>
                </div>
              </div>
              <div class="attempts-history" id="attemptsHistory">
                <h4>Attempt History</h4>
                <div class="history-list" id="historyList"></div>
              </div>
            </div>
            
            <div class="action-section">
              <h3>Actions</h3>
              <button class="btn btn-success" id="swingBtn" onclick="gillidanda.startSwing()">
                <i class="fas fa-baseball-bat"></i> Start Swing
              </button>
              <button class="btn btn-primary" id="hitBtn" onclick="gillidanda.hit()" disabled>
                <i class="fas fa-hand-paper"></i> Hit!
              </button>
              <div class="power-display">
                <span>Power:</span>
                <span id="powerValue">0%</span>
              </div>
            </div>
            
            <div class="info-section">
              <h3>How to Play</h3>
              <div class="instructions">
                <ol>
                  <li>Click "Start Swing" to begin your swing</li>
                  <li>Watch the power meter fill up</li>
                  <li>Click "Hit!" at the right moment for maximum power</li>
                  <li>Try to hit the gilli as far as possible</li>
                  <li>You have 3 attempts to get the highest score</li>
                </ol>
                <div class="tips">
                  <strong>Tips:</strong>
                  <ul>
                    <li>Higher power = longer distance</li>
                    <li>Perfect timing gives bonus points</li>
                    <li>Consistency is key to high scores</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="game-info">
          <div class="info-item">
            <div class="info-label">Current Attempt</div>
            <div class="info-value" id="currentAttempt">1 / 3</div>
          </div>
          <div class="info-item">
            <div class="info-label">Best Distance</div>
            <div class="info-value" id="bestDistance">0m</div>
          </div>
          <div class="info-item">
            <div class="info-label">Game Status</div>
            <div class="info-value" id="gameStatus">Ready to Play</div>
          </div>
        </div>
        
        <div id="gameOver" class="game-over" style="display: none;">
          <h3 id="gameOverTitle">Game Over!</h3>
          <div class="winner" id="winnerText"></div>
          <div class="score" id="finalScore"></div>
          <div class="performance-stats" id="performanceStats"></div>
          <div class="game-over-actions">
            <button class="btn btn-primary" onclick="gillidanda.resetGame()">
              <i class="fas fa-play"></i> Play Again
            </button>
            <button class="btn btn-outline" onclick="gillidanda.closeGame()">
              <i class="fas fa-times"></i> Close
            </button>
          </div>
        </div>
      </div>
    `;

    this.setupEventListeners();
  }

  // Setup event listeners
  setupEventListeners() {
    const gameModeSelect = document.getElementById('gameMode');
    if (gameModeSelect) {
      gameModeSelect.addEventListener('change', (e) => {
        this.gameMode = e.target.value;
        this.resetGame();
      });
    }
  }

  // Start swing power meter
  startSwing() {
    if (this.gameActive || this.currentAttempt >= this.attempts) return;
    
    this.gameActive = true;
    this.power = 0;
    this.powerDirection = 1;
    
    // Update UI
    document.getElementById('swingBtn').disabled = true;
    document.getElementById('hitBtn').disabled = false;
    document.getElementById('gameStatus').textContent = 'Swinging...';
    
    // Start power meter animation
    this.powerInterval = setInterval(() => {
      this.power += this.powerDirection * 2;
      
      if (this.power >= 100) {
        this.power = 100;
        this.powerDirection = -1;
      } else if (this.power <= 0) {
        this.power = 0;
        this.powerDirection = 1;
      }
      
      this.updatePowerDisplay();
    }, 20);
  }

  // Update power display
  updatePowerDisplay() {
    document.getElementById('powerFill').style.width = `${this.power}%`;
    document.getElementById('powerValue').textContent = `${Math.round(this.power)}%`;
  }

  // Hit the gilli
  hit() {
    if (!this.gameActive || this.gilliFlying) return;
    
    // Stop power meter
    if (this.powerInterval) {
      clearInterval(this.powerInterval);
      this.powerInterval = null;
    }
    
    this.gameActive = false;
    this.gilliFlying = true;
    
    // Calculate distance based on power and timing
    const baseDistance = this.power * 2; // Base distance
    const timingBonus = this.calculateTimingBonus();
    const distance = baseDistance + timingBonus;
    
    // Animate the hit
    this.animateHit(distance);
  }

  // Calculate timing bonus
  calculateTimingBonus() {
    // Perfect timing (90-100% power) gives bonus
    if (this.power >= 90 && this.power <= 100) {
      return 50; // Perfect timing bonus
    } else if (this.power >= 75 && this.power < 90) {
      return 25; // Good timing bonus
    } else if (this.power >= 50 && this.power < 75) {
      return 10; // Okay timing bonus
    }
    return 0; // Poor timing
  }

  // Animate the hit
  async animateHit(distance) {
    const gilli = document.getElementById('gilli');
    const danda = document.getElementById('danda');
    const distanceMarker = document.getElementById('distanceMarker');
    
    // Animate danda swing
    danda.classList.add('swinging');
    
    setTimeout(() => {
      // Remove swing animation
      danda.classList.remove('swinging');
      
      // Animate gilli flying
      gilli.classList.add('flying');
      
      // Show distance marker
      distanceMarker.textContent = `${Math.round(distance)}m`;
      distanceMarker.classList.add('show');
      distanceMarker.style.left = `${Math.min(distance * 3, 500)}px`;
      
      // Update score
      const points = Math.round(distance * 10);
      this.currentScore += points;
      this.distances.push(distance);
      
      // Update displays
      document.getElementById('currentScore').textContent = this.currentScore;
      this.updateHistory(distance, points);
      
      // Check for high score
      if (this.currentScore > this.highScore) {
        this.highScore = this.currentScore;
        document.getElementById('highScore').textContent = this.highScore;
      }
      
      // Show feedback
      if (this.power >= 90) {
        showToast('Perfect shot! +50 bonus points!', 'success');
      } else if (this.power >= 75) {
        showToast('Great shot! +25 bonus points!', 'success');
      } else if (this.power >= 50) {
        showToast('Good hit!', 'info');
      } else {
        showToast('Keep practicing!', 'warning');
      }
      
      // Reset for next attempt or end game
      setTimeout(() => {
        this.nextAttempt();
      }, 3000);
    }, 500);
  }

  // Update attempt history
  updateHistory(distance, points) {
    const historyList = document.getElementById('historyList');
    const historyItem = document.createElement('div');
    historyItem.className = 'history-item';
    historyItem.innerHTML = `
      <span>Attempt ${this.currentAttempt + 1}:</span>
      <span>${Math.round(distance)}m (${points} pts)</span>
    `;
    historyList.appendChild(historyItem);
    
    // Update best distance
    const bestDistance = Math.max(...this.distances);
    document.getElementById('bestDistance').textContent = `${Math.round(bestDistance)}m`;
  }

  // Move to next attempt
  nextAttempt() {
    this.currentAttempt++;
    this.gilliFlying = false;
    
    // Reset UI
    const gilli = document.getElementById('gilli');
    const distanceMarker = document.getElementById('distanceMarker');
    gilli.classList.remove('flying');
    distanceMarker.classList.remove('show');
    
    // Reset power
    this.power = 0;
    this.updatePowerDisplay();
    
    // Update attempt counter
    document.getElementById('currentAttempt').textContent = `${this.currentAttempt + 1} / ${this.attempts}`;
    document.getElementById('attemptsLeft').textContent = this.attempts - this.currentAttempt;
    
    // Check if game is over
    if (this.currentAttempt >= this.attempts) {
      this.endGame();
    } else {
      // Reset for next attempt
      document.getElementById('swingBtn').disabled = false;
      document.getElementById('hitBtn').disabled = true;
      document.getElementById('gameStatus').textContent = 'Ready for next attempt';
    }
  }

  // End game
  async endGame() {
    document.getElementById('gameStatus').textContent = 'Game Finished';
    
    const gameOverElement = document.getElementById('gameOver');
    const winnerTextElement = document.getElementById('winnerText');
    const finalScoreElement = document.getElementById('finalScore');
    const performanceStatsElement = document.getElementById('performanceStats');
    
    // Calculate performance metrics
    const avgDistance = this.distances.reduce((a, b) => a + b, 0) / this.distances.length;
    const maxDistance = Math.max(...this.distances);
    const performance = this.calculatePerformance();
    
    let message = '';
    if (this.currentScore >= 2000) {
      message = 'Outstanding performance! You\'re a Gilli Danda master!';
    } else if (this.currentScore >= 1500) {
      message = 'Excellent game! Great technique!';
    } else if (this.currentScore >= 1000) {
      message = 'Good game! Keep practicing to improve!';
    } else {
      message = 'Nice try! Practice makes perfect!';
    }
    
    winnerTextElement.textContent = message;
    finalScoreElement.textContent = `Final Score: ${this.currentScore} points`;
    
    // Performance statistics
    performanceStatsElement.innerHTML = `
      <h4>Performance Statistics</h4>
      <div class="stats-grid">
        <div class="stat-item">
          <span class="stat-label">Average Distance:</span>
          <span class="stat-value">${Math.round(avgDistance)}m</span>
        </div>
        <div class="stat-item">
          <span class="stat-label">Best Distance:</span>
          <span class="stat-value">${Math.round(maxDistance)}m</span>
        </div>
        <div class="stat-item">
          <span class="stat-label">Performance:</span>
          <span class="stat-value">${performance}</span>
        </div>
      </div>
    `;
    
    // Show game over dialog
    if (gameOverElement) {
      gameOverElement.style.display = 'block';
    }
    
    // Create confetti for high scores
    if (this.currentScore >= 1500) {
      setTimeout(() => ui.createConfetti(), 500);
    }
    
    // Submit score to backend
    await this.submitScore();
  }

  // Calculate performance rating
  calculatePerformance() {
    const avgScore = this.currentScore / this.attempts;
    if (avgScore >= 600) return '⭐⭐⭐⭐⭐ Excellent';
    if (avgScore >= 450) return '⭐⭐⭐⭐ Very Good';
    if (avgScore >= 300) return '⭐⭐⭐ Good';
    if (avgScore >= 150) return '⭐⭐ Fair';
    return '⭐ Needs Practice';
  }

  // Submit score to backend
  async submitScore() {
    try {
      const user = auth.getUser();
      if (!user) return;

      const gameData = {
        user: user._id,
        game: this.currentGameId,
        score: this.currentScore,
        gameMode: this.gameMode,
        result: 'completed',
        duration: Math.floor((Date.now() - this.gameStartTime) / 1000),
        moves: this.attempts,
        gameData: {
          distances: this.distances,
          highScore: this.highScore,
          attempts: this.attempts
        }
      };

      await api.submitScore(this.currentGameId, gameData);
      console.log('Score submitted successfully');
    } catch (error) {
      console.error('Error submitting score:', error);
    }
  }

  // Reset game
  resetGame() {
    this.gameActive = false;
    this.currentScore = 0;
    this.currentAttempt = 0;
    this.distances = [];
    this.power = 0;
    this.gilliFlying = false;
    
    // Clear power interval
    if (this.powerInterval) {
      clearInterval(this.powerInterval);
      this.powerInterval = null;
    }
    
    // Reset UI
    document.getElementById('currentScore').textContent = '0';
    document.getElementById('currentAttempt').textContent = '1 / 3';
    document.getElementById('attemptsLeft').textContent = '3';
    document.getElementById('bestDistance').textContent = '0m';
    document.getElementById('gameStatus').textContent = 'Ready to Play';
    document.getElementById('swingBtn').disabled = false;
    document.getElementById('hitBtn').disabled = true;
    document.getElementById('historyList').innerHTML = '';
    
    // Reset gilli and danda
    const gilli = document.getElementById('gilli');
    const danda = document.getElementById('danda');
    const distanceMarker = document.getElementById('distanceMarker');
    gilli.classList.remove('flying');
    danda.classList.remove('swinging');
    distanceMarker.classList.remove('show');
    
    this.updatePowerDisplay();
    
    const gameOverElement = document.getElementById('gameOver');
    if (gameOverElement) {
      gameOverElement.style.display = 'none';
    }
  }

  // Close game
  closeGame() {
    closeGameModal();
  }

  // Set current game ID
  setGameId(gameId) {
    this.currentGameId = gameId;
  }
}

// Create and export game instance
const gilliDanda = new GilliDanda();

// Make globally available
window.gilliDanda = gilliDanda;