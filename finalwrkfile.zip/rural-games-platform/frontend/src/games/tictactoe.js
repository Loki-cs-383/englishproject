// Tic-Tac-Toe Game Module
class TicTacToe {
  constructor() {
    this.board = Array(9).fill('');
    this.currentPlayer = 'X';
    this.gameActive = true;
    this.gameMode = 'single-player'; // 'single-player' or 'multiplayer'
    this.playerSymbol = 'X';
    this.aiSymbol = 'O';
    this.scores = { X: 0, O: 0, draws: 0 };
    this.moveHistory = [];
    this.gameStartTime = null;
    this.currentGameId = null;
    
    // Winning combinations
    this.winningCombinations = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
      [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
      [0, 4, 8], [2, 4, 6] // Diagonals
    ];
  }

  // Initialize game
  init(container) {
    this.container = container;
    this.gameStartTime = Date.now();
    this.createGameBoard();
    this.resetGame();
  }

  // Create game board HTML
  createGameBoard() {
    this.container.innerHTML = `
      <div class="game-container">
        <div class="game-header">
          <h2 class="game-title">Tic-Tac-Toe</h2>
          <div class="game-controls">
            <select id="gameMode" class="game-mode-select">
              <option value="single-player">Single Player</option>
              <option value="multiplayer">Multiplayer</option>
            </select>
            <button class="btn btn-outline" onclick="ticTacToe.resetGame()">
              <i class="fas fa-redo"></i> New Game
            </button>
          </div>
        </div>
        
        <div class="game-board">
          <div class="tictactoe-board" id="tictactoeBoard">
            ${this.createBoardCells()}
          </div>
        </div>
        
        <div class="game-info">
          <div class="info-item">
            <div class="info-label">Current Turn</div>
            <div class="info-value" id="currentTurn">Player X</div>
          </div>
          <div class="info-item">
            <div class="info-label">Game Status</div>
            <div class="info-value" id="gameStatus">Game in Progress</div>
          </div>
          <div class="info-item">
            <div class="info-label">Moves</div>
            <div class="info-value" id="moveCount">0</div>
          </div>
        </div>
        
        <div class="score-board">
          <h3>Score Board</h3>
          <div class="scores">
            <div class="score-item">
              <span class="player-x">Player X:</span>
              <span id="scoreX">0</span>
            </div>
            <div class="score-item">
              <span class="player-o">Player O:</span>
              <span id="scoreO">0</span>
            </div>
            <div class="score-item">
              <span>Draws:</span>
              <span id="scoreDraws">0</span>
            </div>
          </div>
        </div>
        
        <div id="gameOver" class="game-over" style="display: none;">
          <h3 id="gameOverTitle">Game Over!</h3>
          <div class="winner" id="winnerText"></div>
          <div class="score" id="finalScore"></div>
          <div class="game-over-actions">
            <button class="btn btn-primary" onclick="ticTacToe.resetGame()">
              <i class="fas fa-play"></i> Play Again
            </button>
            <button class="btn btn-outline" onclick="ticTacToe.closeGame()">
              <i class="fas fa-times"></i> Close
            </button>
          </div>
        </div>
      </div>
    `;

    this.setupEventListeners();
  }

  // Create board cells HTML
  createBoardCells() {
    let cellsHTML = '';
    for (let i = 0; i < 9; i++) {
      cellsHTML += `<button class="tictactoe-cell" data-index="${i}" onclick="ticTacToe.makeMove(${i})"></button>`;
    }
    return cellsHTML;
  }

  // Setup event listeners
  setupEventListeners() {
    const gameModeSelect = document.getElementById('gameMode');
    if (gameModeSelect) {
      gameModeSelect.addEventListener('change', (e) => {
        this.gameMode = e.target.value;
        this.resetGame();
      });
    }
  }

  // Make a move
  makeMove(index) {
    if (!this.gameActive || this.board[index] !== '') {
      return;
    }

    // Record move
    this.moveHistory.push({
      player: this.currentPlayer,
      position: index,
      timestamp: Date.now()
    });

    // Make the move
    this.board[index] = this.currentPlayer;
    this.updateBoard();
    
    // Check for winner
    const result = this.checkWinner();
    if (result) {
      this.endGame(result);
      return;
    }

    // Switch player
    this.currentPlayer = this.currentPlayer === 'X' ? 'O' : 'X';
    this.updateStatus();

    // If single player and it's AI's turn
    if (this.gameMode === 'single-player' && this.currentPlayer === this.aiSymbol) {
      setTimeout(() => this.makeAIMove(), 500);
    }
  }

  // Make AI move
  makeAIMove() {
    if (!this.gameActive) return;

    const availableMoves = this.board
      .map((cell, index) => cell === '' ? index : null)
      .filter(val => val !== null);

    if (availableMoves.length === 0) return;

    // Simple AI strategy
    let move;

    // Try to win
    move = this.findWinningMove(this.aiSymbol);
    if (move !== -1) {
      this.makeMove(move);
      return;
    }

    // Try to block player
    move = this.findWinningMove(this.playerSymbol);
    if (move !== -1) {
      this.makeMove(move);
      return;
    }

    // Take center if available
    if (this.board[4] === '') {
      this.makeMove(4);
      return;
    }

    // Take a corner
    const corners = [0, 2, 6, 8].filter(i => this.board[i] === '');
    if (corners.length > 0) {
      this.makeMove(corners[Math.floor(Math.random() * corners.length)]);
      return;
    }

    // Take any available move
    const randomMove = availableMoves[Math.floor(Math.random() * availableMoves.length)];
    this.makeMove(randomMove);
  }

  // Find winning move for a player
  findWinningMove(player) {
    for (let combo of this.winningCombinations) {
      const [a, b, c] = combo;
      const line = [this.board[a], this.board[b], this.board[c]];
      
      if (line.filter(cell => cell === player).length === 2 &&
          line.filter(cell => cell === '').length === 1) {
        return combo[line.indexOf('')];
      }
    }
    return -1;
  }

  // Check for winner
  checkWinner() {
    // Check winning combinations
    for (let combo of this.winningCombinations) {
      const [a, b, c] = combo;
      if (this.board[a] && this.board[a] === this.board[b] && this.board[a] === this.board[c]) {
        return {
          winner: this.board[a],
          combination: combo
        };
      }
    }

    // Check for draw
    if (this.board.every(cell => cell !== '')) {
      return { winner: 'draw', combination: null };
    }

    return null;
  }

  // Update board display
  updateBoard() {
    const cells = document.querySelectorAll('.tictactoe-cell');
    cells.forEach((cell, index) => {
      cell.textContent = this.board[index];
      cell.className = 'tictactoe-cell';
      
      if (this.board[index] === 'X') {
        cell.classList.add('x');
      } else if (this.board[index] === 'O') {
        cell.classList.add('o');
      }
    });

    // Highlight winning combination
    const result = this.checkWinner();
    if (result && result.combination) {
      result.combination.forEach(index => {
        cells[index].classList.add('winner');
      });
    }

    // Update move count
    document.getElementById('moveCount').textContent = this.moveHistory.length;
  }

  // Update game status
  updateStatus() {
    const currentTurnElement = document.getElementById('currentTurn');
    const gameStatusElement = document.getElementById('gameStatus');
    
    if (currentTurnElement) {
      const playerName = this.currentPlayer === 'X' ? 'Player X' : 
                       (this.gameMode === 'single-player' ? 'AI (O)' : 'Player O');
      currentTurnElement.textContent = playerName;
    }
    
    if (gameStatusElement && this.gameActive) {
      gameStatusElement.textContent = 'Game in Progress';
    }
  }

  // End game
  async endGame(result) {
    this.gameActive = false;
    const gameOverElement = document.getElementById('gameOver');
    const winnerTextElement = document.getElementById('winnerText');
    const finalScoreElement = document.getElementById('finalScore');
    const gameStatusElement = document.getElementById('gameStatus');

    let winnerText = '';
    let scoreChange = 0;

    if (result.winner === 'draw') {
      winnerText = "It's a Draw!";
      this.scores.draws++;
      scoreChange = 0;
    } else if (result.winner === 'X') {
      winnerText = 'Player X Wins!';
      this.scores.X++;
      scoreChange = 100;
    } else if (result.winner === 'O') {
      if (this.gameMode === 'single-player') {
        winnerText = 'AI Wins!';
      } else {
        winnerText = 'Player O Wins!';
      }
      this.scores.O++;
      scoreChange = this.gameMode === 'single-player' ? 50 : 100;
    }

    // Update display
    if (winnerTextElement) winnerTextElement.textContent = winnerText;
    if (finalScoreElement) {
      finalScoreElement.textContent = `Moves: ${this.moveHistory.length} | Time: ${this.getGameDuration()}`;
    }
    if (gameStatusElement) {
      gameStatusElement.textContent = 'Game Finished';
    }

    // Update score display
    this.updateScoreDisplay();

    // Show game over dialog
    if (gameOverElement) {
      gameOverElement.style.display = 'block';
    }

    // Submit score to backend
    await this.submitScore(result.winner, scoreChange);

    // Create confetti for human player wins
    if (result.winner === 'X' || (result.winner === 'O' && this.gameMode === 'multiplayer')) {
      setTimeout(() => ui.createConfetti(), 500);
    }
  }

  // Get game duration
  getGameDuration() {
    if (!this.gameStartTime) return '0:00';
    const duration = Math.floor((Date.now() - this.gameStartTime) / 1000);
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }

  // Update score display
  updateScoreDisplay() {
    document.getElementById('scoreX').textContent = this.scores.X;
    document.getElementById('scoreO').textContent = this.scores.O;
    document.getElementById('scoreDraws').textContent = this.scores.draws;
  }

  // Submit score to backend
  async submitScore(result, score) {
    try {
      const user = auth.getUser();
      if (!user) return;

      const gameData = {
        user: user._id,
        game: this.currentGameId,
        score: score,
        gameMode: this.gameMode,
        result: result === 'draw' ? 'draw' : (result === this.playerSymbol ? 'win' : 'loss'),
        duration: Math.floor((Date.now() - this.gameStartTime) / 1000),
        moves: this.moveHistory.length,
        gameData: {
          board: this.board,
          movesHistory: this.moveHistory,
          winningCombination: this.checkWinner()?.combination || null
        }
      };

      await api.submitScore(this.currentGameId, gameData);
      console.log('Score submitted successfully');
    } catch (error) {
      console.error('Error submitting score:', error);
    }
  }

  // Reset game
  resetGame() {
    this.board = Array(9).fill('');
    this.currentPlayer = 'X';
    this.gameActive = true;
    this.moveHistory = [];
    this.gameStartTime = Date.now();
    
    this.updateBoard();
    this.updateStatus();
    
    const gameOverElement = document.getElementById('gameOver');
    if (gameOverElement) {
      gameOverElement.style.display = 'none';
    }
  }

  // Close game
  closeGame() {
    closeGameModal();
  }

  // Set current game ID
  setGameId(gameId) {
    this.currentGameId = gameId;
  }

  // Get game statistics
  getStatistics() {
    return {
      totalGames: this.scores.X + this.scores.O + this.scores.draws,
      wins: this.scores.X,
      losses: this.scores.O,
      draws: this.scores.draws,
      winRate: this.scores.X + this.scores.O + this.scores.draws > 0 
        ? (this.scores.X / (this.scores.X + this.scores.O + this.scores.draws) * 100).toFixed(1)
        : 0
    };
  }
}

// Create and export game instance
const ticTacToe = new TicTacToe();

// Make globally available
window.ticTacToe = ticTacToe;