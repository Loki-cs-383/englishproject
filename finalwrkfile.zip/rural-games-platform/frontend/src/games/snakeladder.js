// Snake & Ladder Game Module
class SnakeLadder {
  constructor() {
    this.boardSize = 100;
    this.currentPlayer = 1;
    this.players = [
      { position: 1, token: 'player1-token' },
      { position: 1, token: 'player2-token' }
    ];
    this.gameActive = true;
    this.gameMode = 'single-player';
    this.currentPlayerName = 'Player 1';
    this.aiPlayerName = 'AI';
    this.moveHistory = [];
    this.gameStartTime = null;
    this.currentGameId = null;
    
    // Snake and ladder positions
    this.snakes = {
      16: 6, 47: 26, 49: 11, 56: 53, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 98: 78
    };
    
    this.ladders = {
      1: 38, 4: 14, 9: 31, 21: 42, 28: 84, 36: 44, 51: 67, 71: 91, 80: 100
    };
  }

  // Initialize game
  init(container) {
    this.container = container;
    this.gameStartTime = Date.now();
    this.createGameBoard();
    this.resetGame();
  }

  // Create game board HTML
  createGameBoard() {
    this.container.innerHTML = `
      <div class="game-container">
        <div class="game-header">
          <h2 class="game-title">Snake & Ladder</h2>
          <div class="game-controls">
            <select id="gameMode" class="game-mode-select">
              <option value="single-player">Single Player</option>
              <option value="multiplayer">Multiplayer</option>
            </select>
            <button class="btn btn-outline" onclick="snakeLadder.resetGame()">
              <i class="fas fa-redo"></i> New Game
            </button>
          </div>
        </div>
        
        <div class="game-board">
          <div class="snakeladder-board" id="snakeladderBoard">
            ${this.createBoardCells()}
          </div>
          <div class="dice-container">
            <div class="dice" id="dice" onclick="snakeLadder.rollDice()">
              <i class="fas fa-dice"></i>
            </div>
            <button class="btn btn-primary" id="rollBtn" onclick="snakeLadder.rollDice()">
              Roll Dice
            </button>
            <div class="current-player" id="currentPlayerText">
              ${this.currentPlayerName}'s Turn
            </div>
          </div>
        </div>
        
        <div class="game-info">
          <div class="info-item">
            <div class="info-label">Current Player</div>
            <div class="info-value" id="currentTurn">Player 1</div>
          </div>
          <div class="info-item">
            <div class="info-label">Player 1 Position</div>
            <div class="info-value" id="player1Pos">1</div>
          </div>
          <div class="info-item">
            <div class="info-label">Player 2 Position</div>
            <div class="info-value" id="player2Pos">1</div>
          </div>
          <div class="info-item">
            <div class="info-label">Moves</div>
            <div class="info-value" id="moveCount">0</div>
          </div>
        </div>
        
        <div class="legend">
          <h3>Legend</h3>
          <div class="legend-items">
            <div class="legend-item">
              <div class="legend-color ladder"></div>
              <span>Ladder (Climb Up)</span>
            </div>
            <div class="legend-item">
              <div class="legend-color snake"></div>
              <span>Snake (Slide Down)</span>
            </div>
            <div class="legend-item">
              <div class="legend-color start"></div>
              <span>Start</span>
            </div>
            <div class="legend-item">
              <div class="legend-color end"></div>
              <span>Finish</span>
            </div>
          </div>
        </div>
        
        <div id="gameOver" class="game-over" style="display: none;">
          <h3 id="gameOverTitle">Game Over!</h3>
          <div class="winner" id="winnerText"></div>
          <div class="score" id="finalScore"></div>
          <div class="game-over-actions">
            <button class="btn btn-primary" onclick="snakeLadder.resetGame()">
              <i class="fas fa-play"></i> Play Again
            </button>
            <button class="btn btn-outline" onclick="snakeLadder.closeGame()">
              <i class="fas fa-times"></i> Close
            </button>
          </div>
        </div>
      </div>
    `;

    this.setupEventListeners();
    this.updateTokenPositions();
  }

  // Create board cells HTML
  createBoardCells() {
    let cellsHTML = '';
    
    // Create cells from 100 to 1 (snake and ladder pattern)
    for (let row = 9; row >= 0; row--) {
      for (let col = 0; col < 10; col++) {
        let cellNumber;
        if (row % 2 === 1) { // Odd rows go right to left
          cellNumber = row * 10 + (10 - col);
        } else { // Even rows go left to right
          cellNumber = row * 10 + (col + 1);
        }
        
        let cellClass = 'snakeladder-cell';
        if (cellNumber === 1) cellClass += ' start';
        if (cellNumber === 100) cellClass += ' end';
        if (this.ladders[cellNumber]) cellClass += ' ladder';
        if (this.snakes[cellNumber]) cellClass += ' snake';
        
        cellsHTML += `<div class="${cellClass}" data-position="${cellNumber}">${cellNumber}</div>`;
      }
    }
    
    return cellsHTML;
  }

  // Setup event listeners
  setupEventListeners() {
    const gameModeSelect = document.getElementById('gameMode');
    if (gameModeSelect) {
      gameModeSelect.addEventListener('change', (e) => {
        this.gameMode = e.target.value;
        this.resetGame();
      });
    }
  }

  // Roll dice
  async rollDice() {
    if (!this.gameActive) return;

    const diceElement = document.getElementById('dice');
    const rollBtn = document.getElementById('rollBtn');
    
    // Disable rolling during animation
    diceElement.classList.add('rolling');
    rollBtn.disabled = true;

    // Simulate dice roll
    const diceValue = Math.floor(Math.random() * 6) + 1;
    
    // Animate dice
    await this.animateDice(diceValue);
    
    // Make move
    this.makeMove(diceValue);
    
    // Re-enable rolling
    diceElement.classList.remove('rolling');
    rollBtn.disabled = false;
  }

  // Animate dice roll
  animateDice(finalValue) {
    return new Promise(resolve => {
      const diceElement = document.getElementById('dice');
      let rollCount = 0;
      const maxRolls = 10;
      
      const rollInterval = setInterval(() => {
        const tempValue = Math.floor(Math.random() * 6) + 1;
        diceElement.innerHTML = tempValue;
        rollCount++;
        
        if (rollCount >= maxRolls) {
          clearInterval(rollInterval);
          diceElement.innerHTML = finalValue;
          resolve();
        }
      }, 100);
    });
  }

  // Make a move
  async makeMove(diceValue) {
    const currentPlayerIndex = this.currentPlayer - 1;
    const player = this.players[currentPlayerIndex];
    const oldPosition = player.position;
    let newPosition = oldPosition + diceValue;

    // Don't go beyond 100
    if (newPosition > 100) {
      newPosition = oldPosition;
    }

    // Record move
    this.moveHistory.push({
      player: this.currentPlayer,
      diceValue: diceValue,
      fromPosition: oldPosition,
      toPosition: newPosition,
      timestamp: Date.now()
    });

    // Move token
    player.position = newPosition;
    await this.animateTokenMovement(player.token, oldPosition, newPosition);

    // Check for snakes and ladders
    if (this.snakes[newPosition]) {
      const snakePosition = this.snakes[newPosition];
      setTimeout(async () => {
        showToast(`Oh no! Bitten by a snake! Sliding down to ${snakePosition}`, 'warning');
        player.position = snakePosition;
        await this.animateTokenMovement(player.token, newPosition, snakePosition);
        this.checkWinCondition();
      }, 500);
    } else if (this.ladders[newPosition]) {
      const ladderPosition = this.ladders[newPosition];
      setTimeout(async () => {
        showToast(`Great! Found a ladder! Climbing up to ${ladderPosition}`, 'success');
        player.position = ladderPosition;
        await this.animateTokenMovement(player.token, newPosition, ladderPosition);
        this.checkWinCondition();
      }, 500);
    } else {
      this.checkWinCondition();
    }

    // Update display
    this.updateStatus();
    this.updateTokenPositions();

    // Check if player gets another turn (rolled 6)
    if (diceValue !== 6) {
      this.switchPlayer();
    } else {
      showToast(`Rolled a 6! ${this.currentPlayerName} gets another turn!`, 'info');
    }

    // AI move if single player
    if (this.gameMode === 'single-player' && this.currentPlayer === 2 && this.gameActive) {
      setTimeout(() => this.rollDice(), 1500);
    }
  }

  // Animate token movement
  animateTokenMovement(tokenClass, fromPosition, toPosition) {
    return new Promise(resolve => {
      const token = document.querySelector(`.${tokenClass}`);
      if (!token) {
        resolve();
        return;
      }

      const fromCell = document.querySelector(`[data-position="${fromPosition}"]`);
      const toCell = document.querySelector(`[data-position="${toPosition}"]`);
      
      if (!fromCell || !toCell) {
        resolve();
        return;
      }

      const fromRect = fromCell.getBoundingClientRect();
      const toRect = toCell.getBoundingClientRect();
      
      token.style.transition = 'all 0.5s ease';
      token.style.left = `${toRect.left - fromRect.left + (toRect.width / 2) - 10}px`;
      token.style.top = `${toRect.top - fromRect.top + (toRect.height / 2) - 10}px`;
      
      setTimeout(() => {
        // Update token to new position
        const boardRect = document.getElementById('snakeladderBoard').getBoundingClientRect();
        const newCellRect = toCell.getBoundingClientRect();
        token.style.left = `${newCellRect.left - boardRect.left + (newCellRect.width / 2) - 10}px`;
        token.style.top = `${newCellRect.top - boardRect.top + (newCellRect.height / 2) - 10}px`;
        resolve();
      }, 500);
    });
  }

  // Update token positions
  updateTokenPositions() {
    this.players.forEach((player, index) => {
      const token = document.querySelector(`.${player.token}`);
      const cell = document.querySelector(`[data-position="${player.position}"]`);
      
      if (token && cell) {
        const boardRect = document.getElementById('snakeladderBoard').getBoundingClientRect();
        const cellRect = cell.getBoundingClientRect();
        
        token.style.left = `${cellRect.left - boardRect.left + (cellRect.width / 2) - 10}px`;
        token.style.top = `${cellRect.top - boardRect.top + (cellRect.height / 2) - 10}px`;
      }
    });

    // Update position display
    document.getElementById('player1Pos').textContent = this.players[0].position;
    document.getElementById('player2Pos').textContent = this.players[1].position;
    document.getElementById('moveCount').textContent = this.moveHistory.length;
  }

  // Check win condition
  checkWinCondition() {
    const currentPlayerIndex = this.currentPlayer - 1;
    const player = this.players[currentPlayerIndex];
    
    if (player.position === 100) {
      this.endGame(this.currentPlayer);
    }
  }

  // Switch player
  switchPlayer() {
    this.currentPlayer = this.currentPlayer === 1 ? 2 : 1;
    this.currentPlayerName = this.currentPlayer === 1 ? 'Player 1' : 
                           (this.gameMode === 'single-player' ? this.aiPlayerName : 'Player 2');
    this.updateStatus();
  }

  // Update game status
  updateStatus() {
    document.getElementById('currentTurn').textContent = this.currentPlayerName;
    document.getElementById('currentPlayerText').textContent = `${this.currentPlayerName}'s Turn`;
  }

  // End game
  async endGame(winner) {
    this.gameActive = false;
    const gameOverElement = document.getElementById('gameOver');
    const winnerTextElement = document.getElementById('winnerText');
    const finalScoreElement = document.getElementById('finalScore');

    const winnerName = winner === 1 ? 'Player 1' : 
                      (this.gameMode === 'single-player' ? this.aiPlayerName : 'Player 2');
    
    winnerTextElement.textContent = `${winnerName} Wins!`;
    finalScoreElement.textContent = `Moves: ${this.moveHistory.length} | Time: ${this.getGameDuration()}`;

    // Show game over dialog
    if (gameOverElement) {
      gameOverElement.style.display = 'block';
    }

    // Create confetti for human player wins
    if (winner === 1) {
      setTimeout(() => ui.createConfetti(), 500);
    }

    // Submit score to backend
    const score = winner === 1 ? 1000 : (this.gameMode === 'single-player' ? 100 : 500);
    await this.submitScore(winner, score);
  }

  // Get game duration
  getGameDuration() {
    if (!this.gameStartTime) return '0:00';
    const duration = Math.floor((Date.now() - this.gameStartTime) / 1000);
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }

  // Submit score to backend
  async submitScore(winner, score) {
    try {
      const user = auth.getUser();
      if (!user) return;

      const gameData = {
        user: user._id,
        game: this.currentGameId,
        score: score,
        gameMode: this.gameMode,
        result: winner === 1 ? 'win' : 'loss',
        duration: Math.floor((Date.now() - this.gameStartTime) / 1000),
        moves: this.moveHistory.length,
        gameData: {
          finalPositions: this.players.map(p => p.position),
          movesHistory: this.moveHistory,
          winner: winner
        }
      };

      await api.submitScore(this.currentGameId, gameData);
      console.log('Score submitted successfully');
    } catch (error) {
      console.error('Error submitting score:', error);
    }
  }

  // Reset game
  resetGame() {
    this.currentPlayer = 1;
    this.players = [
      { position: 1, token: 'player1-token' },
      { position: 1, token: 'player2-token' }
    ];
    this.gameActive = true;
    this.moveHistory = [];
    this.gameStartTime = Date.now();
    this.currentPlayerName = 'Player 1';
    
    this.updateStatus();
    this.updateTokenPositions();
    
    const gameOverElement = document.getElementById('gameOver');
    if (gameOverElement) {
      gameOverElement.style.display = 'none';
    }
  }

  // Close game
  closeGame() {
    closeGameModal();
  }

  // Set current game ID
  setGameId(gameId) {
    this.currentGameId = gameId;
  }
}

// Create and export game instance
const snakeLadder = new SnakeLadder();

// Make globally available
window.snakeLadder = snakeLadder;