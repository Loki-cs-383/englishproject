// Kho-Kho Game Module
class KhoKho {
  constructor() {
    this.fieldSize = { width: 8, height: 8 };
    this.players = [];
    this.currentChaser = null;
    this.defenders = [];
    this.gameActive = false;
    this.gameTime = 120; // 2 minutes
    this.timeRemaining = this.gameTime;
    this.scores = { chasers: 0, defenders: 0 };
    this.gameMode = 'single-player';
    this.gameStartTime = null;
    this.currentGameId = null;
    this.selectedDefender = null;
    this.khoTimer = null;
  }

  // Initialize game
  init(container) {
    this.container = container;
    this.gameStartTime = Date.now();
    this.createGameBoard();
    this.resetGame();
  }

  // Create game board HTML
  createGameBoard() {
    this.container.innerHTML = `
      <div class="game-container">
        <div class="game-header">
          <h2 class="game-title">Kho-Kho</h2>
          <div class="game-controls">
            <select id="gameMode" class="game-mode-select">
              <option value="single-player">Single Player</option>
              <option value="multiplayer">Multiplayer</option>
            </select>
            <button class="btn btn-primary" onclick="khokho.startGame()" id="startBtn">
              <i class="fas fa-play"></i> Start Game
            </button>
            <button class="btn btn-outline" onclick="khokho.resetGame()">
              <i class="fas fa-redo"></i> New Game
            </button>
          </div>
        </div>
        
        <div class="game-board">
          <div class="khokho-field" id="khokhoField">
            <div class="khokho-line vertical"></div>
            <div class="khokho-line horizontal"></div>
            ${this.createPlayers()}
          </div>
          
          <div class="game-controls-panel">
            <div class="timer-section">
              <h3>Game Time</h3>
              <div class="timer-display" id="timerDisplay">2:00</div>
              <div class="score-display">
                <div class="score-item">
                  <span>Chasers:</span>
                  <span id="chasersScore">0</span>
                </div>
                <div class="score-item">
                  <span>Defenders:</span>
                  <span id="defendersScore">0</span>
                </div>
              </div>
            </div>
            
            <div class="action-section">
              <h3>Actions</h3>
              <button class="btn btn-success" onclick="khokho.giveKho()" id="khoBtn" disabled>
                <i class="fas fa-exchange-alt"></i> Give Kho
              </button>
              <button class="btn btn-warning" onclick="khokho.tagDefender()" id="tagBtn" disabled>
                <i class="fas fa-hand-paper"></i> Tag Defender
              </button>
            </div>
            
            <div class="info-section">
              <h3>Instructions</h3>
              <div class="instructions">
                <p><strong>As Chaser:</strong></p>
                <ul>
                  <li>Click on a sitting chaser to give kho</li>
                  <li>Click on a nearby defender to tag them</li>
                  <li>Tag all defenders before time runs out</li>
                </ul>
                <p><strong>As Defender:</strong></p>
                <ul>
                  <li>Avoid being tagged by the chaser</li>
                  <li>Move strategically to survive</li>
                  <li>Survive until time runs out to win</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        
        <div class="game-info">
          <div class="info-item">
            <div class="info-label">Current Chaser</div>
            <div class="info-value" id="currentChaser">None</div>
          </div>
          <div class="info-item">
            <div class="info-label">Active Defenders</div>
            <div class="info-value" id="activeDefenders">0</div>
          </div>
          <div class="info-item">
            <div class="info-label">Game Status</div>
            <div class="info-value" id="gameStatus">Ready to Start</div>
          </div>
        </div>
        
        <div id="gameOver" class="game-over" style="display: none;">
          <h3 id="gameOverTitle">Game Over!</h3>
          <div class="winner" id="winnerText"></div>
          <div class="score" id="finalScore"></div>
          <div class="game-over-actions">
            <button class="btn btn-primary" onclick="khokho.resetGame()">
              <i class="fas fa-play"></i> Play Again
            </button>
            <button class="btn btn-outline" onclick="khokho.closeGame()">
              <i class="fas fa-times"></i> Close
            </button>
          </div>
        </div>
      </div>
    `;

    this.setupEventListeners();
  }

  // Create players HTML
  createPlayers() {
    let playersHTML = '';
    
    // Create chasers (team 1)
    for (let i = 0; i < 8; i++) {
      const row = Math.floor(i / 4);
      const col = i % 4;
      const x = col * 150 + 75;
      const y = row * 150 + 75;
      
      playersHTML += `
        <div class="khokho-player chaser sitting" 
             data-index="${i}" 
             data-team="chaser"
             style="left: ${x}px; top: ${y}px;"
             onclick="khokho.selectChaser(${i})">
          C${i + 1}
        </div>
      `;
    }
    
    // Create defenders (team 2)
    for (let i = 0; i < 4; i++) {
      const x = 450 + (i % 2) * 150;
      const y = Math.floor(i / 2) * 150 + 75;
      
      playersHTML += `
        <div class="khokho-player defender active" 
             data-index="${i}" 
             data-team="defender"
             style="left: ${x}px; top: ${y}px;"
             onclick="khokho.selectDefender(${i})">
          D${i + 1}
        </div>
      `;
    }
    
    return playersHTML;
  }

  // Setup event listeners
  setupEventListeners() {
    const gameModeSelect = document.getElementById('gameMode');
    if (gameModeSelect) {
      gameModeSelect.addEventListener('change', (e) => {
        this.gameMode = e.target.value;
        this.resetGame();
      });
    }
  }

  // Start game
  startGame() {
    this.gameActive = true;
    this.gameStartTime = Date.now();
    this.timeRemaining = this.gameTime;
    
    // Set first chaser as active
    this.currentChaser = 0;
    const firstChaser = document.querySelector('.khokho-player.chaser[data-index="0"]');
    if (firstChaser) {
      firstChaser.classList.remove('sitting');
      firstChaser.classList.add('active');
    }
    
    // Update UI
    document.getElementById('startBtn').disabled = true;
    document.getElementById('khoBtn').disabled = false;
    document.getElementById('gameStatus').textContent = 'Game in Progress';
    
    this.updateStatus();
    this.startTimer();
    
    // If single player mode, handle AI
    if (this.gameMode === 'single-player') {
      this.startAIMovement();
    }
  }

  // Start game timer
  startTimer() {
    if (this.khoTimer) {
      clearInterval(this.khoTimer);
    }
    
    this.khoTimer = setInterval(() => {
      this.timeRemaining--;
      this.updateTimerDisplay();
      
      if (this.timeRemaining <= 0) {
        this.endGame('time');
      }
    }, 1000);
  }

  // Update timer display
  updateTimerDisplay() {
    const minutes = Math.floor(this.timeRemaining / 60);
    const seconds = this.timeRemaining % 60;
    document.getElementById('timerDisplay').textContent = 
      `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }

  // Select chaser for kho
  selectChaser(index) {
    if (!this.gameActive || this.currentChaser === null) return;
    
    const selectedChaser = document.querySelector(`.khokho-player.chaser[data-index="${index}"]`);
    const currentChaserElement = document.querySelector('.khokho-player.chaser.active');
    
    // Check if selected chaser is sitting and adjacent to current chaser
    if (selectedChaser && selectedChaser.classList.contains('sitting') && this.isAdjacent(this.currentChaser, index)) {
      this.selectedDefender = index;
      document.getElementById('khoBtn').disabled = false;
    }
  }

  // Give kho to another chaser
  giveKho() {
    if (!this.gameActive || this.selectedDefender === null || this.currentChaser === null) return;
    
    // Deactivate current chaser
    const currentChaserElement = document.querySelector('.khokho-player.chaser.active');
    if (currentChaserElement) {
      currentChaserElement.classList.remove('active');
      currentChaserElement.classList.add('sitting');
    }
    
    // Activate selected chaser
    const newChaserElement = document.querySelector(`.khokho-player.chaser[data-index="${this.selectedDefender}"]`);
    if (newChaserElement) {
      newChaserElement.classList.remove('sitting');
      newChaserElement.classList.add('active');
    }
    
    // Update current chaser
    this.currentChaser = this.selectedDefender;
    this.selectedDefender = null;
    
    // Disable kho button until new selection
    document.getElementById('khoBtn').disabled = true;
    
    this.updateStatus();
    showToast('Kho given successfully!', 'success');
  }

  // Select defender for tagging
  selectDefender(index) {
    if (!this.gameActive || this.currentChaser === null) return;
    
    const defender = document.querySelector(`.khokho-player.defender[data-index="${index}"]`);
    if (defender && defender.classList.contains('active')) {
      this.selectedDefender = index;
      document.getElementById('tagBtn').disabled = false;
    }
  }

  // Tag defender
  tagDefender() {
    if (!this.gameActive || this.selectedDefender === null || this.currentChaser === null) return;
    
    const defender = document.querySelector(`.khokho-player.defender[data-index="${this.selectedDefender}"]`);
    if (defender && this.isNearby(this.currentChaser, this.selectedDefender)) {
      // Tag successful
      defender.classList.remove('active');
      defender.classList.add('tagged');
      this.scores.chasers++;
      
      // Update score display
      document.getElementById('chasersScore').textContent = this.scores.chasers;
      
      // Check if all defenders are tagged
      const activeDefenders = document.querySelectorAll('.khokho-player.defender.active').length;
      if (activeDefenders === 0) {
        this.endGame('chasers');
      }
      
      showToast('Defender tagged!', 'success');
    } else {
      showToast('Too far to tag!', 'warning');
    }
    
    this.selectedDefender = null;
    document.getElementById('tagBtn').disabled = true;
    this.updateStatus();
  }

  // Check if two positions are adjacent
  isAdjacent(index1, index2) {
    const pos1 = this.getPlayerPosition(index1, 'chaser');
    const pos2 = this.getPlayerPosition(index2, 'chaser');
    
    const distance = Math.sqrt(Math.pow(pos1.x - pos2.x, 2) + Math.pow(pos1.y - pos2.y, 2));
    return distance <= 200; // Within 200 pixels
  }

  // Check if chaser is near defender
  isNearby(chaserIndex, defenderIndex) {
    const chaserPos = this.getPlayerPosition(chaserIndex, 'chaser');
    const defenderPos = this.getPlayerPosition(defenderIndex, 'defender');
    
    const distance = Math.sqrt(Math.pow(chaserPos.x - defenderPos.x, 2) + Math.pow(chaserPos.y - defenderPos.y, 2));
    return distance <= 100; // Within 100 pixels
  }

  // Get player position
  getPlayerPosition(index, team) {
    const player = document.querySelector(`.khokho-player.${team}[data-index="${index}"]`);
    if (player) {
      const rect = player.getBoundingClientRect();
      const fieldRect = document.getElementById('khokhoField').getBoundingClientRect();
      return {
        x: rect.left - fieldRect.left + rect.width / 2,
        y: rect.top - fieldRect.top + rect.height / 2
      };
    }
    return { x: 0, y: 0 };
  }

  // Start AI movement for single player mode
  startAIMovement() {
    // Simple AI movement logic
    setInterval(() => {
      if (!this.gameActive || this.gameMode !== 'single-player') return;
      
      // Move defenders randomly
      const defenders = document.querySelectorAll('.khokho-player.defender.active');
      defenders.forEach(defender => {
        if (Math.random() < 0.3) { // 30% chance to move
          this.moveDefender(defender);
        }
      });
    }, 2000);
  }

  // Move defender (AI)
  moveDefender(defender) {
    const currentPos = this.getPlayerPosition(defender.dataset.index, 'defender');
    const field = document.getElementById('khokhoField');
    const fieldRect = field.getBoundingClientRect();
    
    // Random movement within field bounds
    const newX = Math.max(25, Math.min(fieldRect.width - 25, currentPos.x + (Math.random() - 0.5) * 100));
    const newY = Math.max(25, Math.min(fieldRect.height - 25, currentPos.y + (Math.random() - 0.5) * 100));
    
    defender.style.left = `${newX - 15}px`;
    defender.style.top = `${newY - 15}px`;
  }

  // Update game status
  updateStatus() {
    const currentChaserElement = document.querySelector('.khokho-player.chaser.active');
    if (currentChaserElement) {
      document.getElementById('currentChaser').textContent = `Chaser ${parseInt(currentChaserElement.dataset.index) + 1}`;
    }
    
    const activeDefenders = document.querySelectorAll('.khokho-player.defender.active').length;
    document.getElementById('activeDefenders').textContent = activeDefenders;
    document.getElementById('defendersScore').textContent = activeDefenders;
  }

  // End game
  async endGame(reason) {
    this.gameActive = false;
    
    if (this.khoTimer) {
      clearInterval(this.khoTimer);
    }
    
    const gameOverElement = document.getElementById('gameOver');
    const winnerTextElement = document.getElementById('winnerText');
    const finalScoreElement = document.getElementById('finalScore');
    
    let winnerText = '';
    let score = 0;
    
    if (reason === 'chasers') {
      winnerText = 'Chasers Win! All defenders tagged!';
      score = 1000;
    } else if (reason === 'time') {
      const activeDefenders = document.querySelectorAll('.khokho.player.defender.active').length;
      if (activeDefenders > 0) {
        winnerText = 'Defenders Win! Survived until time!';
        score = this.gameMode === 'single-player' ? 500 : 800;
      } else {
        winnerText = 'Chasers Win! All defenders tagged!';
        score = 1000;
      }
    }
    
    const gameDuration = this.getGameDuration();
    winnerTextElement.textContent = winnerText;
    finalScoreElement.textContent = `Time: ${gameDuration} | Final Score: Chasers ${this.scores.chasers} - Defenders ${this.scores.defenders}`;
    
    // Show game over dialog
    if (gameOverElement) {
      gameOverElement.style.display = 'block';
    }
    
    document.getElementById('gameStatus').textContent = 'Game Finished';
    
    // Create confetti for win
    if (reason === 'chasers' || (reason === 'time' && this.gameMode === 'multiplayer')) {
      setTimeout(() => ui.createConfetti(), 500);
    }
    
    // Submit score to backend
    await this.submitScore(score);
  }

  // Get game duration
  getGameDuration() {
    if (!this.gameStartTime) return '0:00';
    const duration = Math.floor((Date.now() - this.gameStartTime) / 1000);
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }

  // Submit score to backend
  async submitScore(score) {
    try {
      const user = auth.getUser();
      if (!user) return;

      const gameData = {
        user: user._id,
        game: this.currentGameId,
        score: score,
        gameMode: this.gameMode,
        result: score >= 800 ? 'win' : 'loss',
        duration: Math.floor((Date.now() - this.gameStartTime) / 1000),
        moves: this.scores.chasers + this.scores.defenders,
        gameData: {
          chasersScore: this.scores.chasers,
          defendersScore: this.scores.defenders,
          timeUsed: this.gameTime - this.timeRemaining
        }
      };

      await api.submitScore(this.currentGameId, gameData);
      console.log('Score submitted successfully');
    } catch (error) {
      console.error('Error submitting score:', error);
    }
  }

  // Reset game
  resetGame() {
    this.gameActive = false;
    this.currentChaser = null;
    this.selectedDefender = null;
    this.scores = { chasers: 0, defenders: 0 };
    this.timeRemaining = this.gameTime;
    
    if (this.khoTimer) {
      clearInterval(this.khoTimer);
    }
    
    // Reset UI
    document.getElementById('startBtn').disabled = false;
    document.getElementById('khoBtn').disabled = true;
    document.getElementById('tagBtn').disabled = true;
    document.getElementById('chasersScore').textContent = '0';
    document.getElementById('defendersScore').textContent = '0';
    document.getElementById('gameStatus').textContent = 'Ready to Start';
    
    // Reset players
    const players = document.querySelectorAll('.khokho-player');
    players.forEach(player => {
      player.classList.remove('active', 'tagged');
      if (player.classList.contains('chaser')) {
        player.classList.add('sitting');
      } else if (player.classList.contains('defender')) {
        player.classList.add('active');
      }
    });
    
    this.updateStatus();
    this.updateTimerDisplay();
    
    const gameOverElement = document.getElementById('gameOver');
    if (gameOverElement) {
      gameOverElement.style.display = 'none';
    }
  }

  // Close game
  closeGame() {
    closeGameModal();
  }

  // Set current game ID
  setGameId(gameId) {
    this.currentGameId = gameId;
  }
}

// Create and export game instance
const khoKho = new KhoKho();

// Make globally available
window.khoKho = khoKho;