#!/bin/bash

# Build script for Rural Games Platform Frontend

echo "🔨 Building Rural Games Platform Frontend..."

# Create build directory
mkdir -p build

# Copy HTML files
echo "📄 Copying HTML files..."
cp index.html build/

# Copy CSS files
echo "🎨 Copying CSS files..."
mkdir -p build/src/styles
cp -r src/styles/* build/src/styles/

# Copy JavaScript files
echo "📜 Copying JavaScript files..."
mkdir -p build/src/utils build/src/components build/src/games build/src/pages
cp src/app.js build/src/
cp -r src/utils/* build/src/utils/
cp -r src/components/* build/src/components/
cp -r src/games/* build/src/games/
cp -r src/pages/* build/src/pages/

# Copy assets
echo "🖼️ Copying assets..."
mkdir -p build/src/assets
cp -r src/assets/* build/src/assets/ 2>/dev/null || :

# Optimize CSS and JS (minify)
if command -v uglifyjs &> /dev/null; then
    echo "🗜️ Minifying JavaScript files..."
    for file in $(find build -name "*.js"); do
        uglifyjs $file -o $file -c -m
    done
fi

if command -v cleancss &> /dev/null; then
    echo "🗜️ Minifying CSS files..."
    for file in $(find build -name "*.css"); do
        cleancss -o $file $file
    done
fi

echo "✅ Build completed successfully!"
echo "📁 Build output is in the 'build' directory"