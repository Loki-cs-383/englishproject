#!/usr/bin/env node

/**
 * Rural Games Platform Deployment Verification Script
 * 
 * This script checks that all components of the deployed application
 * are working correctly.
 */

const fetch = require('node-fetch');
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Configuration
let config = {
  backendUrl: 'http://localhost:5000',
  frontendUrl: 'http://localhost:3000',
  testUser: {
    email: 'test@example.com',
    password: 'Test123!'
  }
};

// ANSI color codes for terminal output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m'
};

// Print colored message
function print(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

// Print header
function printHeader(message) {
  console.log('\n' + '='.repeat(80));
  console.log(`${colors.bright}${colors.cyan}${message}${colors.reset}`);
  console.log('='.repeat(80));
}

// Print success message
function printSuccess(message) {
  console.log(`${colors.green}✓ ${message}${colors.reset}`);
}

// Print error message
function printError(message) {
  console.log(`${colors.red}✗ ${message}${colors.reset}`);
}

// Print warning message
function printWarning(message) {
  console.log(`${colors.yellow}⚠ ${message}${colors.reset}`);
}

// Print info message
function printInfo(message) {
  console.log(`${colors.blue}ℹ ${message}${colors.reset}`);
}

// Sleep function
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Check if a URL is reachable
async function checkUrl(url) {
  try {
    const response = await fetch(url);
    return response.ok;
  } catch (error) {
    return false;
  }
}

// Test backend health
async function testBackendHealth() {
  printHeader('Testing Backend Health');
  
  try {
    const response = await fetch(`${config.backendUrl}/`);
    const data = await response.json();
    
    if (response.ok && data.message) {
      printSuccess(`Backend is healthy: ${data.message}`);
      return true;
    } else {
      printError('Backend health check failed');
      return false;
    }
  } catch (error) {
    printError(`Backend health check failed: ${error.message}`);
    return false;
  }
}

// Test user authentication
async function testAuthentication() {
  printHeader('Testing Authentication');
  
  try {
    // Test registration
    printInfo('Testing user registration...');
    const registerResponse = await fetch(`${config.backendUrl}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: `test_${Date.now()}`,
        email: `test_${Date.now()}@example.com`,
        password: 'Test123!'
      })
    });
    
    const registerData = await registerResponse.json();
    
    if (registerResponse.ok && registerData.token) {
      printSuccess('Registration successful');
    } else {
      printWarning(`Registration failed: ${registerData.error || 'Unknown error'}`);
      printInfo('Trying login with existing user...');
    }
    
    // Test login
    printInfo('Testing user login...');
    const loginResponse = await fetch(`${config.backendUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config.testUser)
    });
    
    const loginData = await loginResponse.json();
    
    if (loginResponse.ok && loginData.token) {
      printSuccess('Login successful');
      return loginData.token;
    } else {
      printError(`Login failed: ${loginData.error || 'Unknown error'}`);
      return null;
    }
  } catch (error) {
    printError(`Authentication test failed: ${error.message}`);
    return null;
  }
}

// Test games API
async function testGamesAPI(token) {
  printHeader('Testing Games API');
  
  try {
    const headers = token ? { 'Authorization': `Bearer ${token}` } : {};
    
    // Get all games
    printInfo('Fetching games list...');
    const gamesResponse = await fetch(`${config.backendUrl}/api/games`, { headers });
    const gamesData = await gamesResponse.json();
    
    if (gamesResponse.ok && gamesData.games) {
      printSuccess(`Found ${gamesData.games.length} games`);
      
      if (gamesData.games.length > 0) {
        const firstGame = gamesData.games[0];
        printInfo(`Testing specific game: ${firstGame.name}`);
        
        // Get specific game
        const gameResponse = await fetch(`${config.backendUrl}/api/games/${firstGame._id}`, { headers });
        const gameData = await gameResponse.json();
        
        if (gameResponse.ok && gameData.game) {
          printSuccess(`Successfully retrieved game: ${gameData.game.name}`);
          return true;
        } else {
          printError('Failed to retrieve specific game');
          return false;
        }
      }
      return true;
    } else {
      printError('Failed to fetch games list');
      return false;
    }
  } catch (error) {
    printError(`Games API test failed: ${error.message}`);
    return false;
  }
}

// Test frontend
async function testFrontend() {
  printHeader('Testing Frontend');
  
  try {
    printInfo('Checking if frontend is accessible...');
    const isReachable = await checkUrl(config.frontendUrl);
    
    if (isReachable) {
      printSuccess('Frontend is accessible');
      return true;
    } else {
      printError('Frontend is not accessible');
      return false;
    }
  } catch (error) {
    printError(`Frontend test failed: ${error.message}`);
    return false;
  }
}

// Main verification function
async function verifyDeployment() {
  printHeader('RURAL GAMES PLATFORM DEPLOYMENT VERIFICATION');
  print('This script will verify that your deployment is working correctly.\n', 'bright');
  
  // Get configuration from user
  await new Promise((resolve) => {
    rl.question(`Backend URL (default: ${config.backendUrl}): `, (answer) => {
      config.backendUrl = answer || config.backendUrl;
      resolve();
    });
  });
  
  await new Promise((resolve) => {
    rl.question(`Frontend URL (default: ${config.frontendUrl}): `, (answer) => {
      config.frontendUrl = answer || config.frontendUrl;
      resolve();
    });
  });
  
  print('\nStarting verification with the following configuration:', 'cyan');
  print(`Backend URL: ${config.backendUrl}`, 'cyan');
  print(`Frontend URL: ${config.frontendUrl}\n`, 'cyan');
  
  // Run tests
  const backendHealthy = await testBackendHealth();
  if (!backendHealthy) {
    printError('Backend health check failed. Verification cannot continue.');
    process.exit(1);
  }
  
  const token = await testAuthentication();
  await testGamesAPI(token);
  await testFrontend();
  
  // Summary
  printHeader('VERIFICATION SUMMARY');
  print('The deployment verification is complete.', 'bright');
  print('Please check the results above for any errors or warnings.', 'bright');
  print('If all tests passed, your deployment is working correctly!', 'green');
  
  rl.close();
}

// Run the verification
verifyDeployment().catch(error => {
  printError(`Verification failed: ${error.message}`);
  process.exit(1);
});