#!/bin/bash

# Rural Games Platform Stop Script
# This script stops both backend and frontend servers

echo "🛑 Stopping Rural Games Platform..."

# Find and kill backend server (port 5000)
BACKEND_PID=$(lsof -ti:5000)
if [ ! -z "$BACKEND_PID" ]; then
    kill -9 $BACKEND_PID 2>/dev/null
    echo "✅ Backend server (port 5000) stopped"
else
    echo "ℹ️  Backend server not running on port 5000"
fi

# Find and kill frontend server (port 3000)
FRONTEND_PID=$(lsof -ti:3000)
if [ ! -z "$FRONTEND_PID" ]; then
    kill -9 $FRONTEND_PID 2>/dev/null
    echo "✅ Frontend server (port 3000) stopped"
else
    echo "ℹ️  Frontend server not running on port 3000"
fi

# Kill any remaining node processes related to this project
pkill -f "node.*server.js" 2>/dev/null
pkill -f "node.*http.server" 2>/dev/null

echo "👋 Rural Games Platform stopped successfully!"