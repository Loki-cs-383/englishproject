const express = require('express');
const { auth } = require('../middleware/auth');
const User = require('../models/User');

const router = express.Router();

// Get User Profile by ID (Public)
router.get('/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    
    const user = await User.findById(userId)
      .select('-password -email -__v')
      .populate('achievements', 'name description icon');

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user: user.getPublicProfile() });

  } catch (error) {
    console.error('Get user profile error:', error);
    res.status(500).json({ error: 'Server error fetching user profile' });
  }
});

// Update Avatar (Protected)
router.put('/avatar', auth, async (req, res) => {
  try {
    const { avatar } = req.body;

    if (!avatar) {
      return res.status(400).json({ error: 'Avatar is required' });
    }

    const user = await User.findByIdAndUpdate(
      req.user._id,
      { avatar },
      { new: true }
    );

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      message: 'Avatar updated successfully',
      user: user.getPublicProfile()
    });

  } catch (error) {
    console.error('Update avatar error:', error);
    res.status(500).json({ error: 'Server error updating avatar' });
  }
});

// Search Users (Public)
router.get('/search/:query', async (req, res) => {
  try {
    const { query } = req.params;
    const { limit = 20, page = 1 } = req.query;

    if (!query || query.length < 2) {
      return res.status(400).json({ 
        error: 'Search query must be at least 2 characters long' 
      });
    }

    const users = await User.find({
      isActive: true,
      $or: [
        { username: { $regex: query, $options: 'i' } },
        { 'profile.firstName': { $regex: query, $options: 'i' } },
        { 'profile.lastName': { $regex: query, $options: 'i' } }
      ]
    })
      .select('username avatar joinDate profile stats')
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .sort({ 'stats.totalScore': -1 });

    const total = await User.countDocuments({
      isActive: true,
      $or: [
        { username: { $regex: query, $options: 'i' } },
        { 'profile.firstName': { $regex: query, $options: 'i' } },
        { 'profile.lastName': { $regex: query, $options: 'i' } }
      ]
    });

    res.json({
      users,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Search users error:', error);
    res.status(500).json({ error: 'Server error searching users' });
  }
});

// Get Leaderboard (Global Users)
router.get('/leaderboard/global', async (req, res) => {
  try {
    const { limit = 50, timeFrame = 'all-time' } = req.query;

    let sortField = 'stats.totalScore';
    if (timeFrame === 'wins') {
      sortField = 'stats.wins';
    } else if (timeFrame === 'games') {
      sortField = 'stats.gamesPlayed';
    }

    const users = await User.find({ isActive: true })
      .select('username avatar joinDate stats')
      .sort({ [sortField]: -1 })
      .limit(parseInt(limit));

    const leaderboard = users.map((user, index) => ({
      rank: index + 1,
      user: {
        _id: user._id,
        username: user.username,
        avatar: user.avatar
      },
      totalScore: user.stats.totalScore,
      gamesPlayed: user.stats.gamesPlayed,
      wins: user.stats.wins,
      winRate: user.stats.gamesPlayed > 0 
        ? Math.round((user.stats.wins / user.stats.gamesPlayed) * 100 * 100) / 100
        : 0
    }));

    res.json({ leaderboard });

  } catch (error) {
    console.error('Get global leaderboard error:', error);
    res.status(500).json({ error: 'Server error fetching global leaderboard' });
  }
});

module.exports = router;