const express = require('express');
const { body, query } = require('express-validator');
const { auth, optionalAuth } = require('../middleware/auth');
const {
  getAllGames,
  getGameById,
  getPopularGames,
  getGamesByCategory,
  getGameCategories,
  playGame,
  rateGame,
  getGameLeaderboard,
  searchGames
} = require('../controllers/gamesController');

const router = express.Router();

// Validation middleware
const validateRateGame = [
  body('rating')
    .isInt({ min: 1, max: 5 })
    .withMessage('Rating must be an integer between 1 and 5')
];

const validateSearch = [
  query('q')
    .notEmpty()
    .withMessage('Search query is required')
    .isLength({ min: 2, max: 100 })
    .withMessage('Search query must be between 2 and 100 characters')
];

// Public routes
router.get('/', getAllGames);
router.get('/popular', getPopularGames);
router.get('/categories', getGameCategories);
router.get('/search', validateSearch, searchGames);
router.get('/category/:category', getGamesByCategory);
router.get('/:id', optionalAuth, getGameById);
router.get('/:id/leaderboard', getGameLeaderboard);

// Protected routes
router.post('/:id/play', auth, playGame);
router.post('/:id/rate', auth, validateRateGame, rateGame);

module.exports = router;