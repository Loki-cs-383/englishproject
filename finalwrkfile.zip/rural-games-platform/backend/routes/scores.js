const express = require('express');
const { body, query } = require('express-validator');
const { auth } = require('../middleware/auth');
const {
  submitScore,
  getUserScores,
  getGameScores,
  getTopScores,
  getUserGameHistory,
  getUserStatistics,
  deleteScore
} = require('../controllers/scoresController');

const router = express.Router();

// Validation middleware
const validateSubmitScore = [
  body('score')
    .isInt({ min: 0 })
    .withMessage('Score must be a non-negative integer'),
  
  body('result')
    .isIn(['win', 'loss', 'draw', 'completed'])
    .withMessage('Result must be win, loss, draw, or completed'),
  
  body('duration')
    .isInt({ min: 0 })
    .withMessage('Duration must be a non-negative integer'),
  
  body('moves')
    .optional()
    .isInt({ min: 0 })
    .withMessage('Moves must be a non-negative integer'),
  
  body('accuracy')
    .optional()
    .isFloat({ min: 0, max: 100 })
    .withMessage('Accuracy must be between 0 and 100'),
  
  body('level')
    .optional()
    .isIn(['beginner', 'intermediate', 'advanced', 'expert'])
    .withMessage('Level must be beginner, intermediate, advanced, or expert'),
  
  body('gameMode')
    .optional()
    .isIn(['single-player', 'multiplayer', 'ai-opponent', 'local-play'])
    .withMessage('Game mode must be single-player, multiplayer, ai-opponent, or local-play')
];

// Protected routes
router.post('/game/:gameId', auth, validateSubmitScore, submitScore);
router.get('/user', auth, getUserScores);
router.get('/user/:userId', auth, getUserScores);
router.get('/user/:userId/history', auth, getUserGameHistory);
router.get('/user/:userId/statistics', auth, getUserStatistics);
router.get('/game/:gameId', getGameScores);
router.get('/game/:gameId/top', getTopScores);
router.delete('/:scoreId', auth, deleteScore);

module.exports = router;