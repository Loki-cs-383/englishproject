const mongoose = require('mongoose');

const scoreSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'User ID is required']
  },
  game: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Game',
    required: [true, 'Game ID is required']
  },
  score: {
    type: Number,
    required: [true, 'Score is required'],
    min: 0
  },
  gameMode: {
    type: String,
    enum: ['single-player', 'multiplayer', 'ai-opponent', 'local-play'],
    default: 'single-player'
  },
  result: {
    type: String,
    enum: ['win', 'loss', 'draw', 'completed'],
    required: true
  },
  duration: {
    type: Number, // in seconds
    required: true
  },
  moves: {
    type: Number,
    default: 0
  },
  accuracy: {
    type: Number,
    min: 0,
    max: 100,
    default: 100
  },
  level: {
    type: String,
    enum: ['beginner', 'intermediate', 'advanced', 'expert'],
    default: 'beginner'
  },
  opponents: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  gameData: {
    boardState: mongoose.Schema.Types.Mixed,
    movesHistory: [mongoose.Schema.Types.Mixed],
    statistics: mongoose.Schema.Types.Mixed
  },
  achievements: [{
    type: String,
    description: String
  }],
  isHighScore: {
    type: Boolean,
    default: false
  },
  verified: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

// Compound index for efficient queries
scoreSchema.index({ user: 1, game: 1 });
scoreSchema.index({ game: 1, score: -1 });
scoreSchema.index({ user: 1, createdAt: -1 });

// Static method to get top scores for a game
scoreSchema.statics.getTopScores = function(gameId, limit = 10) {
  return this.find({ game: gameId, verified: true })
    .populate('user', 'username avatar')
    .sort({ score: -1 })
    .limit(limit);
};

// Static method to get user's best score in a game
scoreSchema.statics.getUserBestScore = function(userId, gameId) {
  return this.findOne({ user: userId, game: gameId })
    .sort({ score: -1 });
};

// Static method to get user's game history
scoreSchema.statics.getUserGameHistory = function(userId, limit = 50) {
  return this.find({ user: userId })
    .populate('game', 'name thumbnail')
    .sort({ createdAt: -1 })
    .limit(limit);
};

// Static method to get leaderboard for a game
scoreSchema.statics.getLeaderboard = function(gameId, timeFrame = 'all-time') {
  let dateFilter = {};
  
  if (timeFrame === 'daily') {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    dateFilter = { createdAt: { $gte: today } };
  } else if (timeFrame === 'weekly') {
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    dateFilter = { createdAt: { $gte: weekAgo } };
  } else if (timeFrame === 'monthly') {
    const monthAgo = new Date();
    monthAgo.setMonth(monthAgo.getMonth() - 1);
    dateFilter = { createdAt: { $gte: monthAgo } };
  }

  return this.aggregate([
    { $match: { game: mongoose.Types.ObjectId(gameId), ...dateFilter, verified: true } },
    {
      $group: {
        _id: '$user',
        bestScore: { $max: '$score' },
        totalScore: { $sum: '$score' },
        gamesPlayed: { $sum: 1 },
        wins: { $sum: { $cond: [{ $eq: ['$result', 'win'] }, 1, 0] } },
        avgDuration: { $avg: '$duration' }
      }
    },
    {
      $lookup: {
        from: 'users',
        localField: '_id',
        foreignField: '_id',
        as: 'userInfo'
      }
    },
    { $unwind: '$userInfo' },
    {
      $project: {
        user: '$userInfo.username',
        avatar: '$userInfo.avatar',
        bestScore: 1,
        totalScore: 1,
        gamesPlayed: 1,
        wins: 1,
        winRate: { $multiply: [{ $divide: ['$wins', '$gamesPlayed'] }, 100] },
        avgDuration: 1
      }
    },
    { $sort: { bestScore: -1 } },
    { $limit: 50 }
  ]);
};

module.exports = mongoose.model('Score', scoreSchema);