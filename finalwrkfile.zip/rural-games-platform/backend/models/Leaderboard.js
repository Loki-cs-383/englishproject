const mongoose = require('mongoose');

const leaderboardSchema = new mongoose.Schema({
  game: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Game',
    required: [true, 'Game ID is required']
  },
  type: {
    type: String,
    enum: ['daily', 'weekly', 'monthly', 'all-time'],
    required: [true, 'Leaderboard type is required']
  },
  period: {
    start: {
      type: Date,
      required: true
    },
    end: {
      type: Date,
      required: true
    }
  },
  entries: [{
    rank: {
      type: Number,
      required: true
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    score: {
      type: Number,
      required: true
    },
    gamesPlayed: {
      type: Number,
      default: 1
    },
    wins: {
      type: Number,
      default: 0
    },
    winRate: {
      type: Number,
      default: 0
    },
    avgDuration: {
      type: Number,
      default: 0
    },
    previousRank: {
      type: Number
    },
    change: {
      type: String,
      enum: ['up', 'down', 'same', 'new'],
      default: 'new'
    }
  }],
  lastUpdated: {
    type: Date,
    default: Date.now
  },
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

// Compound index for efficient queries
leaderboardSchema.index({ game: 1, type: 1, period: 1 });

// Static method to get current leaderboard
leaderboardSchema.statics.getCurrentLeaderboard = function(gameId, type = 'all-time') {
  const now = new Date();
  let periodStart, periodEnd;

  switch (type) {
    case 'daily':
      periodStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      periodEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      break;
    case 'weekly':
      const dayOfWeek = now.getDay();
      periodStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - dayOfWeek);
      periodEnd = new Date(periodStart.getTime() + 7 * 24 * 60 * 60 * 1000);
      break;
    case 'monthly':
      periodStart = new Date(now.getFullYear(), now.getMonth(), 1);
      periodEnd = new Date(now.getFullYear(), now.getMonth() + 1, 1);
      break;
    default: // all-time
      periodStart = new Date(0);
      periodEnd = new Date();
  }

  return this.findOne({
    game: gameId,
    type: type,
    'period.start': { $lte: periodStart },
    'period.end': { $gte: periodEnd },
    isActive: true
  }).populate('entries.user', 'username avatar');
};

// Static method to update leaderboard
leaderboardSchema.statics.updateLeaderboard = function(gameId, type = 'all-time') {
  const Score = mongoose.model('Score');
  
  return this.createOrUpdateLeaderboard(gameId, type)
    .then(() => this.getCurrentLeaderboard(gameId, type));
};

// Instance method to recalculate entries
leaderboardSchema.methods.recalculateEntries = function() {
  const Score = mongoose.model('Score');
  
  let dateFilter = {};
  if (this.type !== 'all-time') {
    dateFilter = {
      createdAt: {
        $gte: this.period.start,
        $lt: this.period.end
      }
    };
  }

  return Score.aggregate([
    { $match: { game: this.game, ...dateFilter, verified: true } },
    {
      $group: {
        _id: '$user',
        bestScore: { $max: '$score' },
        totalScore: { $sum: '$score' },
        gamesPlayed: { $sum: 1 },
        wins: { $sum: { $cond: [{ $eq: ['$result', 'win'] }, 1, 0] } },
        avgDuration: { $avg: '$duration' }
      }
    },
    {
      $lookup: {
        from: 'users',
        localField: '_id',
        foreignField: '_id',
        as: 'userInfo'
      }
    },
    { $unwind: '$userInfo' },
    { $sort: { bestScore: -1 } }
  ])
  .then(results => {
    const oldEntries = this.entries;
    this.entries = [];
    
    results.forEach((result, index) => {
      const rank = index + 1;
      const oldEntry = oldEntries.find(e => e.user.toString() === result._id.toString());
      
      let change = 'new';
      if (oldEntry) {
        if (oldEntry.rank < rank) change = 'down';
        else if (oldEntry.rank > rank) change = 'up';
        else change = 'same';
      }
      
      this.entries.push({
        rank: rank,
        user: result._id,
        score: result.bestScore,
        gamesPlayed: result.gamesPlayed,
        wins: result.wins,
        winRate: (result.wins / result.gamesPlayed) * 100,
        avgDuration: result.avgDuration,
        previousRank: oldEntry ? oldEntry.rank : null,
        change: change
      });
    });
    
    this.lastUpdated = new Date();
    return this.save();
  });
};

// Static helper method for createOrUpdate
leaderboardSchema.statics.createOrUpdateLeaderboard = function(gameId, type) {
  const now = new Date();
  let periodStart, periodEnd;

  switch (type) {
    case 'daily':
      periodStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      periodEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      break;
    case 'weekly':
      const dayOfWeek = now.getDay();
      periodStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - dayOfWeek);
      periodEnd = new Date(periodStart.getTime() + 7 * 24 * 60 * 60 * 1000);
      break;
    case 'monthly':
      periodStart = new Date(now.getFullYear(), now.getMonth(), 1);
      periodEnd = new Date(now.getFullYear(), now.getMonth() + 1, 1);
      break;
    default:
      return Promise.resolve(null);
  }

  return this.findOneAndUpdate(
    {
      game: gameId,
      type: type,
      'period.start': { $lte: periodStart },
      'period.end': { $gte: periodEnd }
    },
    {
      game: gameId,
      type: type,
      period: { start: periodStart, end: periodEnd },
      $setOnInsert: { entries: [], lastUpdated: new Date() }
    },
    { upsert: true, new: true }
  ).then(leaderboard => leaderboard.recalculateEntries());
};

module.exports = mongoose.model('Leaderboard', leaderboardSchema);