const mongoose = require('mongoose');

const gameSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Game name is required'],
    unique: true,
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Game description is required']
  },
  category: {
    type: String,
    enum: ['board', 'outdoor', 'indoor', 'strategy', 'luck'],
    required: [true, 'Game category is required']
  },
  difficulty: {
    type: String,
    enum: ['easy', 'medium', 'hard'],
    default: 'medium'
  },
  minPlayers: {
    type: Number,
    default: 1,
    min: 1
  },
  maxPlayers: {
    type: Number,
    default: 2,
    min: 1
  },
  rules: [{
    type: String
  }],
  instructions: {
    type: String,
    required: true
  },
  thumbnail: {
    type: String,
    default: 'default-game.png'
  },
  images: [{
    type: String
  }],
  isActive: {
    type: Boolean,
    default: true
  },
  features: [{
    type: String,
    enum: ['single-player', 'multiplayer', 'ai-opponent', 'online-play', 'local-play']
  }],
  gameConfig: {
    boardSize: Number,
    timeLimit: Number,
    scoreSystem: String,
    winningConditions: [String]
  },
  popularity: {
    playsCount: { type: Number, default: 0 },
    rating: { type: Number, default: 0, min: 0, max: 5 },
    reviews: { type: Number, default: 0 }
  }
}, {
  timestamps: true
});

// Static method to get popular games
gameSchema.statics.getPopularGames = function(limit = 10) {
  return this.find({ isActive: true })
    .sort({ 'popularity.playsCount': -1 })
    .limit(limit);
};

// Static method to get games by category
gameSchema.statics.getGamesByCategory = function(category) {
  return this.find({ category, isActive: true });
};

// Instance method to increment play count
gameSchema.methods.incrementPlayCount = function() {
  this.popularity.playsCount += 1;
  return this.save();
};

// Instance method to update rating
gameSchema.methods.updateRating = function(newRating) {
  const totalRating = this.popularity.rating * this.popularity.reviews;
  this.popularity.reviews += 1;
  this.popularity.rating = (totalRating + newRating) / this.popularity.reviews;
  return this.save();
};

module.exports = mongoose.model('Game', gameSchema);