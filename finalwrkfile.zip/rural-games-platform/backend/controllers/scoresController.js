const Score = require('../models/Score');
const Game = require('../models/Game');
const User = require('../models/User');
const Leaderboard = require('../models/Leaderboard');

// Submit Score
const submitScore = async (req, res) => {
  try {
    const { gameId } = req.params;
    const { score, gameMode, result, duration, moves, accuracy, level, gameData, achievements } = req.body;

    // Validate required fields
    if (score === undefined || !result || duration === undefined) {
      return res.status(400).json({ 
        error: 'Score, result, and duration are required' 
      });
    }

    // Check if game exists
    const game = await Game.findById(gameId);
    if (!game) {
      return res.status(404).json({ error: 'Game not found' });
    }

    // Get user's best score for this game
    const bestScore = await Score.getUserBestScore(req.user._id, gameId);
    const isHighScore = !bestScore || score > bestScore.score;

    // Create new score entry
    const newScore = new Score({
      user: req.user._id,
      game: gameId,
      score,
      gameMode: gameMode || 'single-player',
      result,
      duration,
      moves: moves || 0,
      accuracy: accuracy || 100,
      level: level || 'beginner',
      gameData,
      achievements: achievements || [],
      isHighScore
    });

    await newScore.save();

    // Update user stats
    const user = await User.findById(req.user._id);
    user.stats.gamesPlayed += 1;
    user.stats.totalScore += score;
    
    if (result === 'win') user.stats.wins += 1;
    else if (result === 'loss') user.stats.losses += 1;
    else if (result === 'draw') user.stats.draws += 1;

    await user.save();

    // Update game popularity
    await game.incrementPlayCount();

    // Update leaderboard (async)
    Leaderboard.updateLeaderboard(gameId, 'all-time').catch(err => {
      console.error('Error updating leaderboard:', err);
    });

    res.status(201).json({
      message: 'Score submitted successfully',
      score: newScore,
      isHighScore,
      userStats: user.stats
    });

  } catch (error) {
    console.error('Submit score error:', error);
    res.status(500).json({ error: 'Server error submitting score' });
  }
};

// Get User Scores
const getUserScores = async (req, res) => {
  try {
    const { gameId, limit = 20, page = 1 } = req.query;
    const userId = req.params.userId || req.user._id;

    let filter = { user: userId };
    if (gameId) filter.game = gameId;

    const scores = await Score.find(filter)
      .populate('game', 'name thumbnail category')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Score.countDocuments(filter);

    res.json({
      scores,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Get user scores error:', error);
    res.status(500).json({ error: 'Server error fetching user scores' });
  }
};

// Get Game Scores
const getGameScores = async (req, res) => {
  try {
    const { gameId } = req.params;
    const { limit = 50, timeFrame = 'all-time' } = req.query;

    // Check if game exists
    const game = await Game.findById(gameId);
    if (!game) {
      return res.status(404).json({ error: 'Game not found' });
    }

    let dateFilter = {};
    const now = new Date();

    switch (timeFrame) {
      case 'daily':
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        dateFilter = { createdAt: { $gte: today } };
        break;
      case 'weekly':
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        dateFilter = { createdAt: { $gte: weekAgo } };
        break;
      case 'monthly':
        const monthAgo = new Date(now.getFullYear(), now.getMonth(), 1);
        dateFilter = { createdAt: { $gte: monthAgo } };
        break;
    }

    const scores = await Score.find({ 
      game: gameId, 
      verified: true,
      ...dateFilter
    })
      .populate('user', 'username avatar')
      .sort({ score: -1, createdAt: -1 })
      .limit(parseInt(limit));

    res.json({ scores });

  } catch (error) {
    console.error('Get game scores error:', error);
    res.status(500).json({ error: 'Server error fetching game scores' });
  }
};

// Get Top Scores
const getTopScores = async (req, res) => {
  try {
    const { gameId } = req.params;
    const { limit = 10 } = req.query;

    // Check if game exists
    const game = await Game.findById(gameId);
    if (!game) {
      return res.status(404).json({ error: 'Game not found' });
    }

    const topScores = await Score.getTopScores(gameId, parseInt(limit));

    res.json({ scores: topScores });

  } catch (error) {
    console.error('Get top scores error:', error);
    res.status(500).json({ error: 'Server error fetching top scores' });
  }
};

// Get User Game History
const getUserGameHistory = async (req, res) => {
  try {
    const { limit = 50 } = req.query;
    const userId = req.params.userId || req.user._id;

    const gameHistory = await Score.getUserGameHistory(userId, parseInt(limit));

    res.json({ gameHistory });

  } catch (error) {
    console.error('Get user game history error:', error);
    res.status(500).json({ error: 'Server error fetching game history' });
  }
};

// Get User Statistics
const getUserStatistics = async (req, res) => {
  try {
    const userId = req.params.userId || req.user._id;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Get additional statistics from scores
    const scoreStats = await Score.aggregate([
      { $match: { user: user._id, verified: true } },
      {
        $group: {
          _id: '$game',
          bestScore: { $max: '$score' },
          gamesPlayed: { $sum: 1 },
          wins: { $sum: { $cond: [{ $eq: ['$result', 'win'] }, 1, 0] } },
          avgScore: { $avg: '$score' },
          totalDuration: { $sum: '$duration' }
        }
      },
      {
        $lookup: {
          from: 'games',
          localField: '_id',
          foreignField: '_id',
          as: 'gameInfo'
        }
      },
      { $unwind: '$gameInfo' },
      {
        $project: {
          game: {
            _id: '$gameInfo._id',
            name: '$gameInfo.name',
            category: '$gameInfo.category',
            thumbnail: '$gameInfo.thumbnail'
          },
          bestScore: 1,
          gamesPlayed: 1,
          wins: 1,
          winRate: { $multiply: [{ $divide: ['$wins', '$gamesPlayed'] }, 100] },
          avgScore: { $round: ['$avgScore', 2] },
          totalPlayTime: '$totalDuration'
        }
      }
    ]);

    const totalPlayTime = scoreStats.reduce((sum, stat) => sum + stat.totalPlayTime, 0);
    const totalWins = scoreStats.reduce((sum, stat) => sum + stat.wins, 0);
    const totalGames = scoreStats.reduce((sum, stat) => sum + stat.gamesPlayed, 0);
    const overallWinRate = totalGames > 0 ? (totalWins / totalGames) * 100 : 0;

    res.json({
      userStats: user.stats,
      gameStats: scoreStats,
      overallStats: {
        totalPlayTime,
        overallWinRate: Math.round(overallWinRate * 100) / 100,
        favoriteGames: scoreStats
          .sort((a, b) => b.gamesPlayed - a.gamesPlayed)
          .slice(0, 3)
          .map(stat => stat.game)
      }
    });

  } catch (error) {
    console.error('Get user statistics error:', error);
    res.status(500).json({ error: 'Server error fetching user statistics' });
  }
};

// Delete Score (User's own score)
const deleteScore = async (req, res) => {
  try {
    const { scoreId } = req.params;

    const score = await Score.findOne({ 
      _id: scoreId, 
      user: req.user._id 
    });

    if (!score) {
      return res.status(404).json({ error: 'Score not found or access denied' });
    }

    await Score.findByIdAndDelete(scoreId);

    res.json({ message: 'Score deleted successfully' });

  } catch (error) {
    console.error('Delete score error:', error);
    res.status(500).json({ error: 'Server error deleting score' });
  }
};

module.exports = {
  submitScore,
  getUserScores,
  getGameScores,
  getTopScores,
  getUserGameHistory,
  getUserStatistics,
  deleteScore
};