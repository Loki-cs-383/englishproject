const Game = require('../models/Game');
const Score = require('../models/Score');
const Leaderboard = require('../models/Leaderboard');

// Get All Games
const getAllGames = async (req, res) => {
  try {
    const { category, difficulty, limit = 20, page = 1 } = req.query;
    
    let filter = { isActive: true };
    
    if (category) filter.category = category;
    if (difficulty) filter.difficulty = difficulty;

    const games = await Game.find(filter)
      .select('-__v')
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .sort({ 'popularity.playsCount': -1 });

    const total = await Game.countDocuments(filter);

    res.json({
      games,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Get all games error:', error);
    res.status(500).json({ error: 'Server error fetching games' });
  }
};

// Get Game by ID
const getGameById = async (req, res) => {
  try {
    const game = await Game.findById(req.params.id)
      .select('-__v');

    if (!game) {
      return res.status(404).json({ error: 'Game not found' });
    }

    // Get user's best score if authenticated
    let userBestScore = null;
    if (req.user) {
      userBestScore = await Score.getUserBestScore(req.user._id, game._id);
    }

    res.json({
      game,
      userBestScore
    });

  } catch (error) {
    console.error('Get game by ID error:', error);
    res.status(500).json({ error: 'Server error fetching game' });
  }
};

// Get Popular Games
const getPopularGames = async (req, res) => {
  try {
    const { limit = 10 } = req.query;
    
    const games = await Game.getPopularGames(parseInt(limit));

    res.json({ games });

  } catch (error) {
    console.error('Get popular games error:', error);
    res.status(500).json({ error: 'Server error fetching popular games' });
  }
};

// Get Games by Category
const getGamesByCategory = async (req, res) => {
  try {
    const { category } = req.params;
    const { limit = 20, page = 1 } = req.query;

    const games = await Game.getGamesByCategory(category)
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .sort({ 'popularity.playsCount': -1 });

    const total = await Game.countDocuments({ category, isActive: true });

    res.json({
      games,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Get games by category error:', error);
    res.status(500).json({ error: 'Server error fetching games by category' });
  }
};

// Get Game Categories
const getGameCategories = async (req, res) => {
  try {
    const categories = await Game.distinct('category', { isActive: true });
    
    const categoryStats = await Promise.all(
      categories.map(async (category) => {
        const count = await Game.countDocuments({ category, isActive: true });
        return { category, count };
      })
    );

    res.json({ categories: categoryStats });

  } catch (error) {
    console.error('Get game categories error:', error);
    res.status(500).json({ error: 'Server error fetching categories' });
  }
};

// Play Game (Track Play)
const playGame = async (req, res) => {
  try {
    const { gameId } = req.params;
    
    const game = await Game.findById(gameId);
    if (!game) {
      return res.status(404).json({ error: 'Game not found' });
    }

    // Increment play count
    await game.incrementPlayCount();

    res.json({ 
      message: 'Game play tracked successfully',
      playsCount: game.popularity.playsCount
    });

  } catch (error) {
    console.error('Play game error:', error);
    res.status(500).json({ error: 'Server error tracking game play' });
  }
};

// Rate Game
const rateGame = async (req, res) => {
  try {
    const { gameId } = req.params;
    const { rating } = req.body;

    if (!rating || rating < 1 || rating > 5) {
      return res.status(400).json({ error: 'Rating must be between 1 and 5' });
    }

    const game = await Game.findById(gameId);
    if (!game) {
      return res.status(404).json({ error: 'Game not found' });
    }

    // Update rating
    await game.updateRating(rating);

    res.json({ 
      message: 'Game rated successfully',
      rating: game.popularity.rating,
      reviews: game.popularity.reviews
    });

  } catch (error) {
    console.error('Rate game error:', error);
    res.status(500).json({ error: 'Server error rating game' });
  }
};

// Get Game Leaderboard
const getGameLeaderboard = async (req, res) => {
  try {
    const { gameId } = req.params;
    const { timeFrame = 'all-time', limit = 10 } = req.query;

    // Check if game exists
    const game = await Game.findById(gameId);
    if (!game) {
      return res.status(404).json({ error: 'Game not found' });
    }

    // Try to get cached leaderboard first
    let leaderboard = await Leaderboard.getCurrentLeaderboard(gameId, timeFrame);
    
    // If no cached leaderboard, generate one
    if (!leaderboard) {
      leaderboard = await Leaderboard.updateLeaderboard(gameId, timeFrame);
    }

    // If still no leaderboard, get top scores
    if (!leaderboard || !leaderboard.entries || leaderboard.entries.length === 0) {
      const topScores = await Score.getTopScores(gameId, parseInt(limit));
      return res.json({
        leaderboard: {
          game: gameId,
          type: timeFrame,
          entries: topScores.map((score, index) => ({
            rank: index + 1,
            user: score.user,
            score: score.score,
            change: 'new'
          }))
        }
      });
    }

    // Limit entries if specified
    if (limit && leaderboard.entries.length > limit) {
      leaderboard.entries = leaderboard.entries.slice(0, parseInt(limit));
    }

    res.json({ leaderboard });

  } catch (error) {
    console.error('Get game leaderboard error:', error);
    res.status(500).json({ error: 'Server error fetching leaderboard' });
  }
};

// Search Games
const searchGames = async (req, res) => {
  try {
    const { q, category, difficulty, limit = 20, page = 1 } = req.query;

    if (!q) {
      return res.status(400).json({ error: 'Search query is required' });
    }

    let filter = {
      isActive: true,
      $or: [
        { name: { $regex: q, $options: 'i' } },
        { description: { $regex: q, $options: 'i' } },
        { category: { $regex: q, $options: 'i' } }
      ]
    };

    if (category) filter.category = category;
    if (difficulty) filter.difficulty = difficulty;

    const games = await Game.find(filter)
      .select('-__v')
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .sort({ 'popularity.playsCount': -1 });

    const total = await Game.countDocuments(filter);

    res.json({
      games,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Search games error:', error);
    res.status(500).json({ error: 'Server error searching games' });
  }
};

module.exports = {
  getAllGames,
  getGameById,
  getPopularGames,
  getGamesByCategory,
  getGameCategories,
  playGame,
  rateGame,
  getGameLeaderboard,
  searchGames
};