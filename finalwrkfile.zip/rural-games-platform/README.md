# Rural Games Platform

A comprehensive web platform for playing traditional rural games online. Built with Node.js, Express, MongoDB, and modern web technologies.

## 🎮 Features

### Core Features
- **6 Traditional Games**: Tic-Tac-Toe, Snake & Ladder, Kho-Kho, Gilli Danda, Pithu, and Kabbadi
- **User Authentication**: Secure registration, login, and profile management
- **Multiplayer Support**: Play against AI or other online players
- **Real-time Gaming**: Socket.io integration for live gameplay
- **Score Tracking**: Comprehensive scoring system with leaderboards
- **Responsive Design**: Mobile-friendly interface that works on all devices

### Advanced Features
- **Leaderboards**: Global, daily, weekly, and monthly rankings
- **Achievement System**: Unlock achievements as you play
- **Game Statistics**: Track your performance and improvement
- **User Profiles**: Customizable profiles with avatars and stats
- **Search & Filter**: Find games by category, difficulty, or name
- **Game History**: View your past games and scores

## 🚀 Technology Stack

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web framework
- **MongoDB** - NoSQL database
- **Mongoose** - MongoDB object modeling
- **Socket.io** - Real-time communication
- **JWT** - Authentication tokens
- **bcryptjs** - Password hashing

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Modern styling with animations
- **JavaScript (ES6+)** - Interactive functionality
- **Responsive Design** - Mobile-first approach
- **Font Awesome** - Icon library

### Development Tools
- **Nodemon** - Development server
- **MongoDB Compass** - Database GUI
- **VS Code** - Code editor (recommended)

## 📁 Project Structure

```
rural-games-platform/
├── backend/                 # Backend application
│   ├── controllers/         # Route controllers
│   ├── models/             # Database models
│   ├── routes/             # API routes
│   ├── middleware/         # Express middleware
│   ├── config/             # Configuration files
│   ├── utils/              # Utility functions
│   ├── server.js           # Main server file
│   └── package.json        # Dependencies
├── frontend/               # Frontend application
│   ├── src/
│   │   ├── styles/         # CSS files
│   │   ├── utils/          # JavaScript utilities
│   │   ├── components/     # Reusable components
│   │   ├── pages/          # Page-specific scripts
│   │   ├── games/          # Game implementations
│   │   └── app.js          # Main application file
│   ├── index.html          # Main HTML file
│   └── package.json        # Dependencies
├── database/               # Database scripts
│   └── init.js             # Database initialization
└── docs/                   # Documentation
    └── README.md           # This file
```

## 🛠️ Installation & Setup

### Prerequisites
- Node.js (v18.x recommended)
- MongoDB (v4.4 or higher)
- Git

### 1. Clone the Repository
```bash
git clone <repository-url>
cd rural-games-platform
```

### 2. Backend Setup

#### Install Dependencies
```bash
cd backend
npm install
```

#### Environment Configuration
Create a `.env` file in the backend directory:
```env
# Server Configuration
PORT=5000
NODE_ENV=development

# Database Configuration
MONGODB_URI=mongodb://localhost:27017/rural-games-platform

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
JWT_EXPIRE=7d

# CORS Configuration
FRONTEND_URL=http://localhost:3000

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

#### Initialize Database
```bash
# From project root
node database/init.js
```

#### Start Backend Server
```bash
cd backend
npm run dev
```

The backend will be running at `http://localhost:5000`

### 3. Frontend Setup

#### Install Dependencies
```bash
cd frontend
npm install
```

#### Start Frontend Server
```bash
npm start
```

The frontend will be running at `http://localhost:3000`

### 4. Access the Application
Open your browser and navigate to `http://localhost:3000`

## 🌐 Deployment

### Quick Deployment

We've provided a convenient deployment script that handles both backend and frontend deployment:

```bash
./deploy.sh
```

This script will:
1. Deploy the backend to Heroku
2. Deploy the frontend to Netlify
3. Configure all necessary environment variables

### Manual Deployment

For detailed deployment instructions, see our comprehensive guides:

- [Comprehensive Deployment Guide](./docs/COMPREHENSIVE_DEPLOYMENT.md) - Complete instructions for all deployment options
- [MongoDB Atlas Setup](./docs/MONGODB_ATLAS_SETUP.md) - Setting up your production database
- [Production Environment Configuration](./docs/PRODUCTION_ENV_CONFIG.md) - Configuring environment variables for production

### Deployment Options

#### Backend
- **Heroku** (Recommended): `./deploy.sh` or follow Heroku-specific instructions
- **AWS Elastic Beanstalk**: See comprehensive guide
- **Docker**: Dockerfile provided in backend directory

#### Frontend
- **Netlify** (Recommended): `./deploy.sh` or use Netlify CLI/Dashboard
- **Vercel**: Use Vercel CLI or GitHub integration
- **AWS S3/CloudFront**: See comprehensive guide

### CI/CD Pipeline

We've included GitHub Actions workflows for continuous integration and deployment:
- Automatic testing on pull requests
- Automatic deployment on merge to main/master branch
- Environment-specific configuration

See `.github/workflows/main.yml` for details.