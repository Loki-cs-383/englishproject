const mongoose = require('mongoose');
require('dotenv').config();

// Import models
const Game = require('../backend/models/Game');
const User = require('../backend/models/User');

// Initial games data
const initialGames = [
  {
    name: 'Tic-Tac-Toe',
    description: 'Classic strategy game where two players take turns marking X and O on a 3x3 grid. First to get three in a row wins!',
    category: 'board',
    difficulty: 'easy',
    minPlayers: 1,
    maxPlayers: 2,
    rules: [
      'Players take turns placing their mark (X or O)',
      'First to get 3 marks in a row wins',
      'Game ends in a draw if all spaces are filled without a winner'
    ],
    instructions: 'Click on any empty cell to place your mark. Try to get three in a row horizontally, vertically, or diagonally.',
    features: ['single-player', 'multiplayer', 'ai-opponent', 'local-play'],
    gameConfig: {
      boardSize: 9,
      timeLimit: 300,
      scoreSystem: 'win-based',
      winningConditions: ['row', 'column', 'diagonal']
    }
  },
  {
    name: 'Snake & Ladder',
    description: 'Traditional board game where players race to reach the final square. Land on a ladder to climb up, or on a snake to slide down!',
    category: 'board',
    difficulty: 'medium',
    minPlayers: 1,
    maxPlayers: 4,
    rules: [
      'Roll dice to move your token',
      'Land on ladder bottom to climb up',
      'Land on snake head to slide down',
      'First to reach square 100 wins'
    ],
    instructions: 'Click the dice to roll. Your token will automatically move. Use ladders to climb up quickly, but avoid snakes!',
    features: ['single-player', 'multiplayer', 'ai-opponent', 'local-play'],
    gameConfig: {
      boardSize: 100,
      timeLimit: 1800,
      scoreSystem: 'completion-based',
      winningConditions: ['reach-end']
    }
  },
  {
    name: 'Kho-Kho',
    description: 'Fast-paced team sport where one team tries to tag the players of the opposing team who are running in a designated area.',
    category: 'outdoor',
    difficulty: 'hard',
    minPlayers: 2,
    maxPlayers: 12,
    rules: [
      'Teams alternate between chasing and defending',
      'Chasers must sit facing opposite direction',
      'Defenders can run freely in the playing area',
      'Tag all defenders to score points'
    ],
    instructions: 'Control your chaser to tag defenders. Use strategic positioning and quick reflexes to catch all opponents.',
    features: ['single-player', 'multiplayer', 'ai-opponent', 'local-play'],
    gameConfig: {
      boardSize: 64,
      timeLimit: 600,
      scoreSystem: 'tag-based',
      winningConditions: ['tag-all', 'time-limit']
    }
  },
  {
    name: 'Gilli Danda',
    description: 'Ancient traditional game similar to cricket. Players use a stick (danda) to strike a smaller stick (gilli) and score runs.',
    category: 'outdoor',
    difficulty: 'medium',
    minPlayers: 1,
    maxPlayers: 6,
    rules: [
      'Hit the gilli with the danda to send it flying',
      'Measure distance to score runs',
      'Opponents try to catch the gilli',
      'Player with highest score wins'
    ],
    instructions: 'Click and drag to aim, release to strike the gilli. Try to hit it as far as possible to score maximum runs.',
    features: ['single-player', 'multiplayer', 'ai-opponent', 'local-play'],
    gameConfig: {
      boardSize: 200,
      timeLimit: 900,
      scoreSystem: 'distance-based',
      winningConditions: ['high-score']
    }
  },
  {
    name: 'Pithu',
    description: 'Traditional team game where one team builds a tower of stones and the other tries to knock it down while avoiding being tagged.',
    category: 'outdoor',
    difficulty: 'medium',
    minPlayers: 4,
    maxPlayers: 10,
    rules: [
      'Builders stack stones in a tower',
      'Hitters try to knock down the tower',
      'Builders must rebuild while avoiding tags',
      'Game continues until a team gives up'
    ],
    instructions: 'Take turns hitting the stone tower. As a builder, quickly rebuild the tower while avoiding the hitters.',
    features: ['multiplayer', 'local-play'],
    gameConfig: {
      boardSize: 49,
      timeLimit: 1200,
      scoreSystem: 'tower-based',
      winningConditions: ['tower-destruction', 'time-limit']
    }
  },
  {
    name: 'Kabbadi',
    description: 'Contact team sport where players raid the opponent\'s court to tag defenders and return safely while chanting "kabaddi".',
    category: 'outdoor',
    difficulty: 'hard',
    minPlayers: 2,
    maxPlayers: 14,
    rules: [
      'Raider enters opponent\'s court',
      'Must chant "kabaddi" continuously',
      'Tag defenders and return to own court',
      'Defenders try to stop the raider'
    ],
    instructions: 'Control your raider to tag opponents and return safely. Maintain your breath and avoid getting caught!',
    features: ['single-player', 'multiplayer', 'ai-opponent', 'local-play'],
    gameConfig: {
      boardSize: 81,
      timeLimit: 120,
      scoreSystem: 'raid-based',
      winningConditions: ['points-based', 'time-limit']
    }
  }
];

// Connect to database and initialize
async function initializeDatabase() {
  try {
    console.log('Connecting to MongoDB...');
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/rural-games-platform');
    console.log('Connected to MongoDB successfully!');

    // Clear existing games
    console.log('Clearing existing games...');
    await Game.deleteMany({});
    console.log('Existing games cleared.');

    // Insert initial games
    console.log('Inserting initial games...');
    const insertedGames = await Game.insertMany(initialGames);
    console.log(`${insertedGames.length} games inserted successfully!`);

    // Display inserted games
    console.log('\nInserted Games:');
    insertedGames.forEach((game, index) => {
      console.log(`${index + 1}. ${game.name} (${game.category})`);
    });

    console.log('\nDatabase initialization completed successfully!');

  } catch (error) {
    console.error('Database initialization error:', error);
  } finally {
    await mongoose.disconnect();
    console.log('Disconnected from MongoDB.');
  }
}

// Run initialization if this file is executed directly
if (require.main === module) {
  initializeDatabase();
}

module.exports = { initializeDatabase, initialGames };